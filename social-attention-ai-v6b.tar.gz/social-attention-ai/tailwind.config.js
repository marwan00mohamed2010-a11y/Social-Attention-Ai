/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // "teal" is remapped to a calm teal blue so every existing teal-* class follows the new palette.
        teal: {
          50: '#eef8f9', 100: '#d3eef0', 200: '#a8dde2', 300: '#6fc4cd', 400: '#3aa6b3',
          500: '#228c9b', 600: '#1b7280', 700: '#195c68', 800: '#184c56', 900: '#173f47',
        },
        mint: { 50: '#f1fbf6', 100: '#dff5ea', 200: '#bfeadb', 300: '#93d9c0', 400: '#5fc2a2' },
        beige: { 50: '#fbf7f0', 100: '#f5ecdc', 200: '#ecdcc0', 300: '#dfc79b' },
        cream: '#fffaf0',
        coral: { 400: '#ffa57e', 500: '#f98550', 600: '#ec6c3b', 700: '#d4512a' },
      },
      fontFamily: {
        // Arabic-capable system fonts are listed so Arabic glyphs render on Windows, macOS, and Android.
        sans: ['system-ui', '-apple-system', 'Segoe UI', 'Tahoma', 'Geeza Pro', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
      },
    },
  },
  plugins: [],
};

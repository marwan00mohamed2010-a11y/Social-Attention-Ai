# Social Attention AI

An early social-attention and gaze screening **prototype** (Behavioral Screening & Research Prototype, not a medical diagnosis). It runs entirely in the browser. Video is processed locally with MediaPipe FaceLandmarker (478 landmarks with iris, plus facial transformation matrices). No frames or landmarks are uploaded.

## Setup

Requires Node.js 18 or newer and a webcam.

```bash
npm install          # also copies the MediaPipe Wasm runtime and tries to download the face model
npm run fetch-model  # only needed if the model download failed during install
npm run dev          # http://localhost:5173 (camera access needs localhost or HTTPS)
npm run build        # static output in dist/, deployable to any static host
npm run test:logic   # unit tests for gaze math, metrics, and synthetic validation
```

The face model is `public/models/face_landmarker.task`. If the automatic download is blocked, fetch it manually from the URL printed by the setup script and save it to that path. Without it the pre-check reports a clear error.

## Offline and conference-hall use

- The Wasm runtime is served from `public/mediapipe/wasm/`, and the model from `public/models/`. Neither needs the internet at runtime.
- Stimuli are drawn on Canvas and use no image or video URLs.
- Run `npm run build` ahead of time and serve `dist/` from a local laptop or kiosk. The app then needs no network at all.

## Screens

1. **Intro**: animated cat guide, privacy explanation, Start.
2. **Profile**: nickname/ID, age, avatar; saved only in `localStorage`, with a delete button.
3. **Camera check**: mirrored preview with oval guide, face/centering/tracking-stability/lighting checks. A check that cannot be verified is shown as "not verified", never as passed.
4. **Calibration**: five targets; stability is judged by leave-one-out error. Unstable calibration offers Recalibrate / Continue anyway.
5. **Assessment**: 15 s split screen (generated animations, or clips from `public/stimuli/`). Debug overlay shows mesh, iris, estimated gaze arrow, head pose, FPS, latency, tracking confidence.
6. **Report**: measured vs estimated metrics, quality gate, timeline, exact index formula, methodology, limitations, privacy, print/PDF, CSV exports.
7. **Engineering**: live FPS/latency/memory/camera status, privacy audit, and clearly labelled SYNTHETIC simulations (kept separate from real sessions).

The cat speaks only through hand-written speech bubbles (`cat.*` strings). There is no voice, TTS or generated dialogue.

## Project layout

```
src/
  lib/            gazeMath (iris + pose + calibration fit), metrics (scoring), synthetic, visionEngine, perfMonitor, exportUtils, constants
  hooks/          useVisionPipeline (camera + detection loop), useAnimatedCanvas
  components/     Welcome, Calibration, Assessment, DebugOverlay, Report, EngineeringPanel, stimuli, ui
tests/logic.test.mjs   deterministic checks that need no browser
training/              gaze-regressor training pipeline prototype (see its README)
scripts/setup-mediapipe.mjs
```

## Important limitations

- This is an experimental research prototype, **not** a diagnostic tool. It never classifies a child; results cannot establish or exclude ASD.
- Gaze coordinates are ESTIMATES from a standard webcam. No accuracy has been validated against a reference eye tracker.
- The Experimental Attention Index weights are arbitrary design choices, not fitted or validated. The quality-control limits (60% valid data, 60% tracking confidence, 25% calibration error) are engineering choices.
- Tracking confidence is a heuristic (face continuity x position steadiness), not a model probability.
- No model has been trained. See `training/README.md`.
- Offline operation is NOT verified end to end. Assets are bundled locally; test by disconnecting the network after the first load.
- Head-pose sign conventions for the transformation matrix are assumed; calibration absorbs a constant offset or sign flip, but verify on a real device.
- Generated animations are not recorded research stimuli (see `public/stimuli/README.md`).


## Phase 3: low-light engineering, calibration accuracy, realistic face stimulus

**What changed and why (calibration).** Calibration now fits on 5 targets and is judged on 4 *separate* interior
targets that are never used in the fit (`validationError`). The 25% gate is unchanged. Leave-one-out is still
shown, but it extrapolates (a held-out corner is outside the other points), so it overstated error. Fixes in
`gazeMath.js`: head-pose angles can no longer wrap at ±180°; vertical iris position is measured against the eye
corners (not the tiny, blink-sensitive eyelid gap); blink/invalid-eye frames are dropped; per-target values are
medians; the fit is standardised ridge with a floor on feature spread, so a head held still is not fitted to noise.
I could not reproduce the reported ~84% in simulation (only ~8-22% LOO), so the exact cause on your hardware is
**not confirmed**. Vision Lab → "Last calibration diagnostics" shows which feature set gives the lowest held-out
error on your real data.

**Low-light enhancement (`src/lib/enhance.js`).** Adaptive gamma, face-ROI CLAHE, light denoise, optional gray-world
white balance, hysteresis auto mode. Output has the same pixel size as the input, so no coordinate transform is
needed. It is **OFF by default**. Whether it improves MediaPipe is unmeasured until you run the A/B in Vision Lab on
your camera; the lab only recommends it if every run in a lighting condition shows ≥5 pts more valid tracking, no
worse iris jitter, and ≥30 FPS. Node timing of the enhancer alone: ~4 ms per 640×480 frame (browser canvas
read/write cost is extra and unmeasured).

**Quality monitor (`quality.js`).** Separate face / eye / iris-steadiness scores from a rolling window; the lighting
verdict follows tracking evidence (dim-but-steady passes; bright-but-unstable does not). Thresholds are engineering
choices, not validated cut-offs.

**Camera (`cameraCaps.js`).** Reads getSupportedConstraints/getCapabilities/getSettings; only controls the camera
reports are ever touched; the optional exposure assist makes at most 3 steps and reverts if a step doesn't help.
Resolution/fps sweep is in Vision Lab. **Not tested by me on a Dell Precision 7510 webcam.**

**Vision Lab.** Engineering panel → Open Vision Lab (developer-only, English). Records only real measurements;
export JSON/CSV. Calibration error per lighting condition is recorded by running the normal calibration with the
chosen enhancement mode, then "Record to results".

**Social stimulus.** Left half is a generated realistic-style human face (blinks, head tilt/nod, eye-contact
glances, warm smile). It is an illustration, not a photograph. Engineering panel lets you load a local photo/.mp4/.webm
instead (in memory only, never uploaded; use only faces you have permission to show). Timer, 50/50 boundary and
gaze classification are unchanged; the right half is still abstract geometry. Whether this face is an adequate
GeoPref stimulus is not validated.

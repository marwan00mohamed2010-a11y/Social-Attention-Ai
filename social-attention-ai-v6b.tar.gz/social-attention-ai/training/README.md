# Gaze-mapping training pipeline (prototype)

## Status (honest)
| Item | State |
|---|---|
| Trainable model in the app | **None.** The app uses MediaPipe FaceLandmarker for landmarks, plus a per-session 5-point linear fit. |
| Training on real data | **Not done.** No dataset is bundled and none was downloaded. |
| Pipeline code | Done: `train_gaze_regressor.mjs` (subject-wise split, validation-only tuning, two baselines, held-out test). |
| Verified on | **Synthetic data only** (`npm run train:selftest`). That shows the code runs, not that anything is accurate. |
| Accuracy / validation claims | **None.** |

## What it tests
Does a degree-2 regressor on (iris offset, head yaw/pitch) predict screen position better than the app's current
linear mapping, on subjects it has never seen? Only a real multi-subject dataset can answer that.

## To run on real data
1. Get a **properly licensed** dataset (or collect your own with consent and ethics approval; never use data from children without it).
2. Extract the same features the app uses (`irisX, irisY, yawDeg, pitchDeg`) with a known screen target (`tx, ty`) per frame.
   The app's "Calibration features CSV" export already has this format (one `session` per run).
3. `node training/train_gaze_regressor.mjs yourdata.csv` (needs at least 10 distinct subjects).
4. Only adopt a trained model in the app if the held-out test error beats the linear baseline by a clear margin.

## Not done
Converting image/video gaze datasets (e.g. via MediaPipe) into this CSV format; any autism-related model (not attempted, and not scientifically justified here).

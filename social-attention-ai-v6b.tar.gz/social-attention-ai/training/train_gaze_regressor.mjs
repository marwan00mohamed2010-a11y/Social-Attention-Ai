// Gaze-mapping training pipeline PROTOTYPE (Node, no dependencies).
//
// Goal: test whether a slightly richer regressor maps MediaPipe features (iris offset + head pose) to screen
// position better than the app's current per-session linear calibration, on HELD-OUT subjects.
//
// Input CSV (header required). Accepted columns, with aliases:
//   subject|session, irisX, irisY, yawDeg, pitchDeg, tx|target_x, ty|target_y
// The app's "Calibration features CSV" export already uses this format.
//
// Usage:
//   node training/train_gaze_regressor.mjs data.csv
//   node training/train_gaze_regressor.mjs --selftest      (SYNTHETIC data, verifies the code only)
//
// Safeguards: split is BY SUBJECT (no frame of a test subject is ever seen in training/validation),
// the regularisation strength is chosen on the validation split only, and the test split is used once.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fitLinear } from '../src/lib/gazeMath.js';

const SELFTEST = process.argv.includes('--selftest');
const MIN_SUBJECTS = 10;

function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function parseCsv(path) {
  const [head, ...lines] = readFileSync(path, 'utf8').trim().split(/\r?\n/);
  const cols = head.split(',').map((c) => c.trim());
  const idx = (...names) => cols.findIndex((c) => names.includes(c));
  const m = { s: idx('subject', 'session'), ix: idx('irisX'), iy: idx('irisY'), yaw: idx('yawDeg'), pit: idx('pitchDeg'), tx: idx('tx', 'target_x'), ty: idx('ty', 'target_y') };
  for (const [k, v] of Object.entries(m)) if (v < 0) throw new Error(`Missing CSV column for "${k}"`);
  return lines.map((l) => {
    const c = l.split(',');
    return { subject: c[m.s], ix: +c[m.ix], iy: +c[m.iy], yaw: +c[m.yaw], pit: +c[m.pit], tx: +c[m.tx], ty: +c[m.ty] };
  }).filter((r) => [r.ix, r.iy, r.yaw, r.pit, r.tx, r.ty].every(Number.isFinite));
}

// SYNTHETIC generator, used only by --selftest. Non-linear on purpose so the pipeline has something to find.
function syntheticData() {
  const rnd = mulberry32(7);
  const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-9)) * Math.cos(2 * Math.PI * rnd());
  const rows = [];
  for (let s = 0; s < 40; s++) {
    const gain = 0.8 + rnd() * 0.4;
    for (let i = 0; i < 60; i++) {
      const tx = rnd(); const ty = rnd();
      const yaw = (rnd() - 0.5) * 24; const pit = (rnd() - 0.5) * 16;
      const ix = 0.5 + (tx - 0.5) * 0.5 * gain - yaw * 0.004 + 0.06 * (tx - 0.5) ** 2 + gauss() * 0.01;
      const iy = 0.5 + (ty - 0.5) * 0.4 * gain - pit * 0.004 + 0.05 * (ty - 0.5) ** 2 + gauss() * 0.01;
      rows.push({ subject: `SYN-${s}`, ix, iy, yaw, pit, tx, ty });
    }
  }
  return rows;
}

const featLinear = (r) => ({ x: [1, r.ix, r.yaw], y: [1, r.iy, r.pit] });
const featPoly = (r) => ({
  x: [1, r.ix, r.yaw, r.ix * r.ix, r.ix * r.yaw, r.iy, r.iy * r.ix],
  y: [1, r.iy, r.pit, r.iy * r.iy, r.iy * r.pit, r.ix, r.ix * r.iy],
});

function train(rows, feat, ridge) {
  const F = rows.map(feat);
  return { wx: fitLinear(F.map((f) => f.x), rows.map((r) => r.tx), ridge), wy: fitLinear(F.map((f) => f.y), rows.map((r) => r.ty), ridge) };
}
const predict = (m, feat, r) => {
  const f = feat(r);
  return { x: m.wx.reduce((a, w, i) => a + w * f.x[i], 0), y: m.wy.reduce((a, w, i) => a + w * f.y[i], 0) };
};
function evaluate(predictFn, rows) {
  const e = rows.map((r) => { const p = predictFn(r); return Math.hypot(p.x - r.tx, p.y - r.ty); }).sort((a, b) => a - b);
  return { n: e.length, mean: e.reduce((a, b) => a + b, 0) / e.length, median: e[Math.floor(e.length / 2)], p90: e[Math.floor(e.length * 0.9)] };
}

const rows = SELFTEST ? syntheticData() : parseCsv(process.argv[2] ?? (() => { throw new Error('Usage: node train_gaze_regressor.mjs data.csv | --selftest'); })());
const subjects = [...new Set(rows.map((r) => r.subject))];
if (subjects.length < MIN_SUBJECTS) {
  console.error(`Need at least ${MIN_SUBJECTS} distinct subjects for a leakage-free train/val/test split; found ${subjects.length}. Nothing was trained.`);
  process.exit(1);
}

const rnd = mulberry32(2026);
const shuffled = [...subjects].sort(() => rnd() - 0.5);
const nTest = Math.max(2, Math.round(subjects.length * 0.2));
const nVal = Math.max(2, Math.round(subjects.length * 0.2));
const split = { test: new Set(shuffled.slice(0, nTest)), val: new Set(shuffled.slice(nTest, nTest + nVal)) };
const part = (r) => (split.test.has(r.subject) ? 'test' : split.val.has(r.subject) ? 'val' : 'train');
const data = { train: rows.filter((r) => part(r) === 'train'), val: rows.filter((r) => part(r) === 'val'), test: rows.filter((r) => part(r) === 'test') };

// Choose ridge strength on VALIDATION only.
let best = null;
for (const ridge of [1e-6, 1e-4, 1e-3, 1e-2, 1e-1, 1]) {
  const m = train(data.train, featPoly, ridge);
  const e = evaluate((r) => predict(m, featPoly, r), data.val).mean;
  if (!best || e < best.valErr) best = { ridge, valErr: e, model: m };
}

const meanT = { x: data.train.reduce((a, r) => a + r.tx, 0) / data.train.length, y: data.train.reduce((a, r) => a + r.ty, 0) / data.train.length };
const linear = train(data.train, featLinear, 1e-6);
const report = {
  synthetic: SELFTEST,
  note: SELFTEST ? 'SYNTHETIC DATA. Verifies the pipeline only. This is NOT evidence of real-world accuracy.' : 'Real-data run. Check dataset licence and consent before sharing results.',
  subjects: { total: subjects.length, train: shuffled.length - nTest - nVal, val: nVal, test: nTest },
  frames: { train: data.train.length, val: data.val.length, test: data.test.length },
  chosenRidge: best.ridge,
  testError: {
    baselineConstantCentre: evaluate(() => meanT, data.test),
    baselineLinear: evaluate((r) => predict(linear, featLinear, r), data.test),
    candidatePoly: evaluate((r) => predict(best.model, featPoly, r), data.test),
  },
  unit: 'normalised screen units (1.0 = full screen width/height); Euclidean error',
};
const base = report.testError.baselineLinear.mean;
const cand = report.testError.candidatePoly.mean;
report.relativeImprovementOverLinear = (base - cand) / base;

mkdirSync(new URL('./out/', import.meta.url), { recursive: true });
const tag = SELFTEST ? 'selftest' : 'run';
writeFileSync(new URL(`./out/report.${tag}.json`, import.meta.url), JSON.stringify(report, null, 2));
writeFileSync(new URL(`./out/model.${tag}.json`, import.meta.url), JSON.stringify({ synthetic: SELFTEST, features: 'see featPoly in train_gaze_regressor.mjs', ridge: best.ridge, wx: best.model.wx, wy: best.model.wy }, null, 2));
console.log(JSON.stringify(report, null, 2));
if (SELFTEST) console.log('\nSELF-TEST ONLY: synthetic data. No training on real participants has been performed.');

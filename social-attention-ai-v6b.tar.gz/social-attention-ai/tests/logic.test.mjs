// Logic tests for the pure math/scoring modules. Run with: npm run test:logic
import assert from 'node:assert/strict';
import { fitCalibration, mapToScreen, classifyGaze, calibrationResidual, calibrationLooError, validationError, headPoseFromMatrix, extractIrisFeatures } from '../src/lib/gazeMath.js';
import { enhanceRGBA, lumaStats, adaptiveGamma, clahe, AutoEnhanceGate } from '../src/lib/enhance.js';
import { QualityWindow, assessTracking, imageScore } from '../src/lib/quality.js';
import { summariseFrames, compareAB, recommendByLighting } from '../src/lib/abHarness.js';
import { drawHumanFace, SKIN_PRESETS } from '../src/lib/faceStimulus.js';
import { analyzeSession, assessQuality } from '../src/lib/metrics.js';
import { generateSynthetic, SYNTHETIC_PROFILES } from '../src/lib/synthetic.js';
import { ZONE, SYNTH_TOLERANCE_PTS } from '../src/lib/constants.js';
import { STRINGS } from '../src/i18n/strings.js';
import { computeGuidance, GUIDE } from '../src/lib/guidance.js';

let passed = 0;
const test = (name, fn) => { fn(); passed++; console.log('  ok  ', name); };

const truth = (f) => ({ x: 0.1 + 0.8 * f.irisX + 0.01 * f.yawDeg, y: 0.05 + 0.9 * f.irisY + 0.005 * f.pitchDeg });
// Feature values must be non-collinear across points, or the fit is underdetermined.
const feats = [
  { irisX: 0.50, irisY: 0.50, yawDeg: 0, pitchDeg: 0 },
  { irisX: 0.20, irisY: 0.30, yawDeg: -12, pitchDeg: 6 },
  { irisX: 0.80, irisY: 0.25, yawDeg: 11, pitchDeg: -4 },
  { irisX: 0.25, irisY: 0.85, yawDeg: -8, pitchDeg: 9 },
  { irisX: 0.75, irisY: 0.70, yawDeg: 14, pitchDeg: -7 },
];

test('calibration recovers a synthetic linear gaze mapping', () => {
  const pts = feats.map((f) => ({ ...f, x: truth(f).x, y: truth(f).y }));
  const cal = fitCalibration(pts);
  const probe = { irisX: 0.6, irisY: 0.55, yawDeg: 7, pitchDeg: -3 };
  const got = mapToScreen(cal, probe);
  const want = truth(probe);
  assert.ok(Math.abs(got.x - want.x) < 1e-3 && Math.abs(got.y - want.y) < 1e-3);
  assert.ok(calibrationResidual(cal) < 1e-3);
});

test('leave-one-out error is ~0 for clean data and large for noisy data', () => {
  const clean = feats.map((f) => ({ ...f, x: truth(f).x, y: truth(f).y }));
  assert.ok(calibrationLooError(clean, fitCalibration(clean).ridge) < 2e-2);
  const offsets = [[0.3, -0.2], [-0.25, 0.3], [0.2, 0.25], [-0.3, -0.2], [0.25, -0.3]];
  const noisy = feats.map((f, i) => ({ ...f, x: truth(f).x + offsets[i][0], y: truth(f).y + offsets[i][1] }));
  const nl = calibrationLooError(noisy, fitCalibration(noisy).ridge);
  assert.ok(nl > 0.15 && nl > 8 * calibrationLooError(clean, fitCalibration(clean).ridge), `loo=${nl}`);
  assert.equal(calibrationLooError(clean.slice(0, 3)), null);
});

test('zone classification: halves and off-screen margins', () => {
  assert.equal(classifyGaze(0.2, 0.5, true), ZONE.SOCIAL);
  assert.equal(classifyGaze(0.8, 0.5, true), ZONE.NON_SOCIAL);
  assert.equal(classifyGaze(0.5, 0.5, false), ZONE.OFF);
  assert.equal(classifyGaze(1.2, 0.5, true), ZONE.OFF);
  assert.equal(classifyGaze(NaN, 0.5, true), ZONE.OFF);
});

for (const id of ['typical', 'asd']) {
  test(`synthetic profile ${id} reproduces its target social share (engine check)`, () => {
    const p = SYNTHETIC_PROFILES[id];
    const r = analyzeSession(generateSynthetic(id));
    assert.equal(r.valid, true);
    assert.ok(Math.abs(r.socialFixationPct - p.targetPct) <= SYNTH_TOLERANCE_PTS, `target ${p.targetPct}, got ${r.socialFixationPct.toFixed(1)}`);
    assert.ok(Math.abs(r.socialFixationPct + r.nonSocialFixationPct - 100) < 1e-9);
  });
}

test('metrics expose valid-data %, tracking confidence and no diagnostic class', () => {
  const r = analyzeSession(generateSynthetic('typical'));
  assert.ok(r.validDataPct > 80 && r.validDataPct <= 100);
  assert.ok(r.trackingConfidence > 0.5 && r.trackingConfidence <= 1);
  assert.equal(r.classification, undefined);
  const sum = r.sai.components.reduce((a, c) => a + c.contribution, 0);
  assert.ok(Math.abs(sum - r.sai.score) < 1e-9 && r.sai.score >= 0 && r.sai.score <= 100);
});

test('too little valid gaze is rejected instead of scored', () => {
  const samples = Array.from({ length: 60 }, (_, i) => ({ t: i * 33, zone: ZONE.OFF, conf: 0 }));
  assert.equal(analyzeSession(samples).valid, false);
});

test('quality gate flags low valid data, low tracking confidence and unstable calibration', () => {
  const good = analyzeSession(generateSynthetic('typical'));
  assert.equal(assessQuality(good, 0.05).ok, true);
  const calibBad = assessQuality(good, 0.4);
  assert.equal(calibBad.ok, false);
  assert.equal(calibBad.reasons[0].key, 'rCalib');
  const lowConf = analyzeSession(generateSynthetic('typical').map((s) => ({ ...s, conf: 0.2 })));
  assert.ok(assessQuality(lowConf, null).reasons.some((r) => r.key === 'rTrack'));
});

test('every translation key exists in both English and Arabic', () => {
  const en = Object.keys(STRINGS.en).sort();
  const ar = Object.keys(STRINGS.ar).sort();
  assert.deepEqual(ar, en);
  for (const k of en) assert.ok(STRINGS.ar[k].trim().length > 0, `empty Arabic string for ${k}`);
});

test('no UI string labels synthetic data as ASD / a real child, and none claims diagnosis', () => {
  for (const lang of ['en', 'ar']) {
    assert.ok(!/ASD Biomarker/i.test(STRINGS[lang]['profile.asd']));
  }
  assert.ok(/SYNTHETIC/i.test(STRINGS.en['synth.banner']));
});

// ---- Pre-check guidance (mirrored display: displayed x = 1 - raw x).
const frameFromBox = (minX, maxX, minY, maxY) => {
  const mid = { x: (minX + maxX) / 2, y: (minY + maxY) / 2 };
  const landmarks = Array.from({ length: 478 }, () => ({ ...mid }));
  landmarks[0] = { x: minX, y: minY };
  landmarks[1] = { x: maxX, y: maxY };
  return { faceFound: true, landmarks };
};

test('guidance rules', () => {
  assert.equal(computeGuidance(null).key, GUIDE.NO_FACE);
  assert.equal(computeGuidance(frameFromBox(0.35, 0.65, 0.3, 0.7)).aligned, true);
  assert.equal(computeGuidance(frameFromBox(0.45, 0.5, 0.3, 0.7)).key, GUIDE.CLOSER);
  assert.equal(computeGuidance(frameFromBox(0.0, 0.9, 0.0, 0.9)).key, GUIDE.BACK);
  assert.equal(computeGuidance(frameFromBox(0.2, 0.45, 0.3, 0.7)).key, GUIDE.LEFT);
  assert.equal(computeGuidance(frameFromBox(0.55, 0.8, 0.3, 0.7)).key, GUIDE.RIGHT);
  assert.equal(computeGuidance(frameFromBox(0.35, 0.65, 0.05, 0.35)).key, GUIDE.DOWN);
  assert.equal(computeGuidance(frameFromBox(0.35, 0.65, 0.65, 0.95)).key, GUIDE.UP);
  assert.equal(computeGuidance(frameFromBox(0.05, 0.3, 0.05, 0.35)).key, GUIDE.CENTER);
});

test('held-out validation error is measured on points not used in the fit', () => {
  const pts = feats.map((f) => ({ ...f, x: truth(f).x, y: truth(f).y }));
  const cal = fitCalibration(pts);
  const val = [{ irisX: 0.4, irisY: 0.45, yawDeg: -3, pitchDeg: 2 }, { irisX: 0.65, irisY: 0.6, yawDeg: 5, pitchDeg: -1 }].map((f) => ({ ...f, x: truth(f).x, y: truth(f).y }));
  assert.ok(validationError(cal, val).mean < 0.02);
  const bad = val.map((v) => ({ ...v, x: v.x + 0.3 }));
  assert.ok(validationError(cal, bad).mean > 0.25);
});

test('a feature that does not vary (still head) is not fitted to noise', () => {
  // Head perfectly still apart from tiny noise: pose must not dominate the mapping.
  const pts = [[0.5, 0.5], [0.1, 0.1], [0.9, 0.1], [0.1, 0.9], [0.9, 0.9]].map(([x, y], i) => ({
    x, y, irisX: 0.5 + (x - 0.5) * 0.2, irisY: 0.5 + (y - 0.5) * 0.1, yawDeg: 0.05 * ((i * 7) % 3 - 1), pitchDeg: 0.05 * ((i * 5) % 3 - 1),
  }));
  const cal = fitCalibration(pts);
  const p = mapToScreen(cal, { irisX: 0.5 + 0.3 * 0.2, irisY: 0.5 - 0.2 * 0.1, yawDeg: 0.4, pitchDeg: -0.4 });
  assert.ok(Math.abs(p.x - 0.8) < 0.08 && Math.abs(p.y - 0.3) < 0.08, `got ${p.x}, ${p.y}`);
});

test('head pose angles stay within +-90 degrees whichever way the forward axis points', () => {
  const m = (yaw, flip) => {
    const c = Math.cos(yaw), sn = Math.sin(yaw);
    const d = new Array(16).fill(0);
    d[0] = c; d[2] = -sn; d[5] = 1; d[8] = sn; d[10] = c; d[15] = 1; // column-major rotation about Y
    if (flip) { d[8] = -d[8]; d[10] = -d[10]; d[0] = -d[0]; d[2] = -d[2]; }
    return d;
  };
  for (const flip of [false, true]) {
    const a = headPoseFromMatrix(m(0.3, flip));
    const b = headPoseFromMatrix(m(-0.3, flip));
    assert.ok(Math.abs(a.yawDeg) <= 90 && Math.abs(a.pitchDeg) <= 90);
    assert.ok(a.yawDeg * b.yawDeg < 0, 'yaw changes sign with direction');
  }
});

test('blink / closed eye is flagged invalid', () => {
  const mk = (gap) => {
    const lm = Array.from({ length: 478 }, () => ({ x: 0.5, y: 0.5 }));
    Object.assign(lm[33], { x: 0.3, y: 0.5 }); Object.assign(lm[133], { x: 0.4, y: 0.5 });
    Object.assign(lm[468], { x: 0.35, y: 0.5 }); Object.assign(lm[159], { x: 0.35, y: 0.5 - gap }); Object.assign(lm[145], { x: 0.35, y: 0.5 + gap });
    Object.assign(lm[362], { x: 0.6, y: 0.5 }); Object.assign(lm[263], { x: 0.7, y: 0.5 });
    Object.assign(lm[473], { x: 0.65, y: 0.5 }); Object.assign(lm[386], { x: 0.65, y: 0.5 - gap }); Object.assign(lm[374], { x: 0.65, y: 0.5 + gap });
    return lm;
  };
  assert.equal(extractIrisFeatures(mk(0.015)).eyeValid, true);
  assert.equal(extractIrisFeatures(mk(0.002)).eyeValid, false);
});

test('enhancement brightens a dark frame, keeps size, and leaves a well-lit frame nearly unchanged', () => {
  const w = 96, h = 96;
  const mkFrame = (lo, hi) => { const a = new Uint8ClampedArray(w * h * 4); for (let i = 0; i < w * h; i++) { const v = lo + ((i * 37) % 100) / 100 * (hi - lo); a[i * 4] = v; a[i * 4 + 1] = v; a[i * 4 + 2] = v; a[i * 4 + 3] = 255; } return a; };
  const dark = mkFrame(10, 50);
  const before = lumaStats(dark).p50;
  enhanceRGBA(dark, w, h, {}, { x: 16, y: 16, w: 64, h: 64 });
  assert.equal(dark.length, w * h * 4);
  assert.ok(lumaStats(dark).p50 > before + 20, `median ${before} -> ${lumaStats(dark).p50}`);
  assert.ok(adaptiveGamma(130) >= 0.9 && adaptiveGamma(20) < 0.7);
  const l = new Uint8ClampedArray(64 * 64).map((_, i) => 100 + (i % 20));
  const spread = (a) => Math.max(...a) - Math.min(...a);
  const s0 = spread(l);
  clahe(l, 64, 64, 4, 2.0);
  assert.ok(spread(l) > s0, 'CLAHE raises local contrast');
});

test('auto-enhance gate has hysteresis and does not flicker', () => {
  const g = new AutoEnhanceGate({ onBelow: 85, offAbove: 105, holdFrames: 3 });
  const seq = [90, 80, 80, 80, 80, 95, 95, 95, 95, 110, 110, 110, 110];
  const states = seq.map((m) => g.update(m));
  assert.equal(states[0], false);
  assert.equal(states[4], true);
  assert.equal(states[8], true, 'stays on at 95 (between thresholds)');
  assert.equal(states[12], false);
  let flips = 0; for (let i = 1; i < states.length; i++) if (states[i] !== states[i - 1]) flips++;
  assert.ok(flips <= 2);
});

test('quality: dark-but-tracking passes, bright-but-unreliable does not', () => {
  const run = (frames) => { const w = new QualityWindow(45); frames.forEach((f) => w.push(f)); return w; };
  const good = Array.from({ length: 45 }, (_, i) => ({ faceFound: true, eyeValid: true, irisX: 0.5 + Math.sin(i / 9) * 0.002, irisY: 0.5 }));
  const noisy = Array.from({ length: 45 }, (_, i) => ({ faceFound: true, eyeValid: i % 3 !== 0, irisX: 0.5 + (i % 2) * 0.08, irisY: 0.5 }));
  const darkStats = { mean: 40, p5: 20, p50: 35, p95: 80, contrast: 0.24, clipLow: 0, clipHigh: 0 };
  const brightStats = { mean: 150, p5: 80, p50: 150, p95: 230, contrast: 0.59, clipLow: 0, clipHigh: 0 };
  const a = assessTracking(imageScore(darkStats), run(good));
  assert.equal(a.level, 'ok');
  assert.ok(a.reasons.includes('darkButTracking'));
  const b = assessTracking(imageScore(brightStats), run(noisy));
  assert.notEqual(b.level, 'ok');
  assert.equal(assessTracking(null, run(good.slice(0, 5))).level, 'measuring');
});

test('A/B summary and decision rule use only observed values', () => {
  const mk = (valid, ms) => Array.from({ length: 100 }, (_, i) => ({ found: true, eyeValid: i < valid, irisX: 0.5 + (i % 2) * 0.001, irisY: 0.5, nose: { x: 100 + (i % 2), y: 100 }, ms }));
  const A = summariseFrames(mk(60, 10));
  const Bgood = summariseFrames(mk(80, 12));
  const Bsame = summariseFrames(mk(61, 12));
  const Bslow = summariseFrames(mk(90, 40));
  assert.equal(Math.round(A.validTrackingPct), 60);
  assert.equal(compareAB(A, Bgood).verdict, 'B better');
  assert.equal(compareAB(A, Bsame).verdict, 'no clear difference');
  assert.notEqual(compareAB(A, Bslow).verdict, 'B better');
  assert.equal(compareAB(null, A).verdict, 'insufficient');
  const one = [{ kind: 'ab', lighting: 'weak', A, B: Bgood }];
  assert.match(recommendByLighting(one).weak.recommendation, /keep original/, 'one run is not enough');
  assert.match(recommendByLighting([...one, ...one]).weak.recommendation, /use enhancement/);
});

test('human face stimulus draws with valid canvas arguments over time and for every skin tone', () => {
  const bad = [];
  const ctx = new Proxy({}, {
    get: (_, name) => {
      if (name === 'createLinearGradient' || name === 'createRadialGradient') {
        return (...a) => { if (a.some((v) => !Number.isFinite(v))) bad.push(name); if (name === 'createRadialGradient' && (a[2] < 0 || a[5] < 0)) bad.push('negative gradient radius'); return { addColorStop() {} }; };
      }
      return (...a) => {
        if (a.some((v) => typeof v === 'number' && !Number.isFinite(v))) bad.push(`${String(name)} NaN`);
        if ((name === 'ellipse' && (a[2] < 0 || a[3] < 0)) || (name === 'arc' && a[2] < 0)) bad.push(`${String(name)} negative radius`);
      };
    },
    set: () => true,
  });
  for (const skin of Object.keys(SKIN_PRESETS)) for (let t = 0; t < 30; t += 0.37) drawHumanFace(ctx, 640, 600, t, { skin });
  assert.deepEqual(bad, []);
});

console.log(`\n${passed} logic tests passed`);

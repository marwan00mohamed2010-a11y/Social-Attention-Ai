import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { STRINGS } from './strings.js';

const I18nContext = createContext(null);

/** Language state, document direction, and the translate function `t(key, vars)`. */
export function I18nProvider({ children }) {
  const [lang, setLang] = useState('en');

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  const t = useCallback(
    (key, vars) => {
      const str = STRINGS[lang][key] ?? STRINGS.en[key] ?? key;
      return vars ? str.replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? '')) : str;
    },
    [lang],
  );

  const value = useMemo(
    () => ({ lang, setLang, t, isAr: lang === 'ar', dir: lang === 'ar' ? 'rtl' : 'ltr' }),
    [lang, t],
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used inside I18nProvider');
  return ctx;
}

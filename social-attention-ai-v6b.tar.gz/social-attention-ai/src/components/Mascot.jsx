// Original full-body cartoon cat. Pure SVG + CSS (see index.css, ".cat-*"). No libraries, no audio.
// States: idle | greeting | explaining | waiting | encouraging | success | error

const TEAL = '#2a8f9d';
const TEAL_DARK = '#1b6f7c';
const MINT = '#bff0dc';
const NAVY = '#173f47';
const CORAL = '#f98550';

const Star = ({ x, y, d }) => (
  <path
    className="cat-sparkle"
    style={{ animationDelay: `${d}s`, transformOrigin: `${x}px ${y}px` }}
    d={`M${x} ${y - 9} L${x + 3} ${y - 3} L${x + 9} ${y} L${x + 3} ${y + 3} L${x} ${y + 9} L${x - 3} ${y + 3} L${x - 9} ${y} L${x - 3} ${y - 3} Z`}
    fill="#ffd166"
  />
);

function Mouth({ state }) {
  if (state === 'success' || state === 'greeting' || state === 'encouraging') {
    return (
      <g>
        <path d="M98 111 Q110 132 122 111 Z" fill="#8a3b3b" />
        <ellipse cx="110" cy="123" rx="6" ry="3.5" fill={CORAL} />
      </g>
    );
  }
  if (state === 'error') {
    return <path d="M101 119 Q110 112 119 119" fill="none" stroke={NAVY} strokeWidth="2.6" strokeLinecap="round" />;
  }
  return <path d="M100 113 Q110 122 120 113" fill="none" stroke={NAVY} strokeWidth="2.6" strokeLinecap="round" />;
}

export default function Mascot({ state = 'idle', size = 180, className = '' }) {
  const concerned = state === 'error';
  return (
    <svg
      viewBox="0 0 220 300"
      width={size}
      height={(size * 300) / 220}
      className={`cat-svg cat-${state} ${className}`}
      role="img"
      aria-hidden="true"
    >
      <ellipse cx="110" cy="288" rx="52" ry="7" fill="#000" opacity="0.08" />
      <g className="cat-root">
        {/* Tail */}
        <g className="cat-tail">
          <path d="M148 226 C196 224 214 170 190 142" fill="none" stroke={TEAL} strokeWidth="17" strokeLinecap="round" />
          <circle cx="190" cy="142" r="9" fill={MINT} />
        </g>

        <g className="cat-breathe">
          {/* Legs and feet */}
          <rect x="80" y="226" width="26" height="50" rx="13" fill={TEAL_DARK} />
          <rect x="114" y="226" width="26" height="50" rx="13" fill={TEAL_DARK} />
          <ellipse cx="91" cy="277" rx="21" ry="9" fill={MINT} />
          <ellipse cx="129" cy="277" rx="21" ry="9" fill={MINT} />

          {/* Body and belly */}
          <rect x="65" y="140" width="90" height="102" rx="42" fill={TEAL} />
          <ellipse cx="110" cy="196" rx="28" ry="37" fill={MINT} />

          {/* Arms (rotation comes from CSS per state) */}
          <g className="cat-arm-l">
            <rect x="44" y="152" width="22" height="62" rx="11" fill={TEAL} />
            <circle cx="55" cy="216" r="12" fill={MINT} />
          </g>
          <g className="cat-arm-r">
            <rect x="154" y="152" width="22" height="62" rx="11" fill={TEAL} />
            <circle cx="165" cy="216" r="12" fill={MINT} />
            {state === 'explaining' && <ellipse cx="165" cy="231" rx="4.5" ry="10" fill={MINT} />}
          </g>

          {/* Head */}
          <g className="cat-head">
            <path d="M68 72 L62 26 L100 54 Z" fill={TEAL} />
            <path d="M152 72 L158 26 L120 54 Z" fill={TEAL} />
            <path d="M72 64 L69 40 L90 56 Z" fill={MINT} />
            <path d="M148 64 L151 40 L130 56 Z" fill={MINT} />
            <ellipse cx="110" cy="98" rx="54" ry="47" fill={TEAL} />
            <path d="M104 54 L104 66 M110 52 L110 66 M116 54 L116 66" stroke={TEAL_DARK} strokeWidth="3" strokeLinecap="round" />
            <ellipse cx="110" cy="112" rx="27" ry="19" fill={MINT} />
            <ellipse cx="78" cy="110" rx="8" ry="5" fill={CORAL} opacity="0.3" />
            <ellipse cx="142" cy="110" rx="8" ry="5" fill={CORAL} opacity="0.3" />

            {/* Eyes */}
            <g className="cat-eyes">
              <ellipse cx="91" cy="92" rx="12" ry="14" fill="#fff" />
              <ellipse cx="129" cy="92" rx="12" ry="14" fill="#fff" />
              <g className="cat-pupils">
                <circle cx="91" cy="94" r="7" fill={NAVY} />
                <circle cx="129" cy="94" r="7" fill={NAVY} />
                <circle cx="93.5" cy="91" r="2.4" fill="#fff" />
                <circle cx="131.5" cy="91" r="2.4" fill="#fff" />
              </g>
            </g>

            {/* Brows: raised arcs normally, slanted when concerned */}
            {concerned ? (
              <g stroke={NAVY} strokeWidth="3" strokeLinecap="round" fill="none">
                <path d="M78 80 L102 71" />
                <path d="M118 71 L142 80" />
              </g>
            ) : (
              <g stroke={TEAL_DARK} strokeWidth="3" strokeLinecap="round" fill="none">
                <path d="M80 75 Q91 69 102 74" />
                <path d="M118 74 Q129 69 140 75" />
              </g>
            )}

            {/* Nose, mouth, whiskers */}
            <path d="M105 103 L115 103 L110 109 Z" fill={CORAL} />
            <Mouth state={state} />
            <g stroke={TEAL_DARK} strokeWidth="1.6" strokeLinecap="round" opacity="0.7">
              <path d="M84 110 L62 106 M84 115 L63 118" />
              <path d="M136 110 L158 106 M136 115 L157 118" />
            </g>
          </g>
        </g>

        {state === 'success' && (
          <g>
            <Star x={36} y={60} d={0} />
            <Star x={186} y={52} d={0.3} />
            <Star x={22} y={130} d={0.6} />
            <Star x={200} y={120} d={0.15} />
          </g>
        )}
      </g>
    </svg>
  );
}

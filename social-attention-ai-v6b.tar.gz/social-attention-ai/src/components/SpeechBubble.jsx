import { useEffect, useState } from 'react';

/**
 * Reusable speech bubble. Text is always hand-written (see i18n/strings.js, keys "cat.*").
 * When `text` changes the old message animates out, then the new one animates in.
 */
export default function SpeechBubble({ text, className = '' }) {
  const [view, setView] = useState({ text, phase: 'in' });

  useEffect(() => {
    if (text === view.text) return undefined;
    setView((v) => ({ ...v, phase: 'out' }));
    const id = setTimeout(() => setView({ text, phase: 'in' }), 170);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text]);

  if (!view.text) return null;
  return (
    <div
      role="status"
      aria-live="polite"
      className={`relative max-w-xs rounded-3xl border-2 border-teal-200 bg-white px-4 py-3 text-base font-medium leading-snug text-teal-900 shadow-sm ${
        view.phase === 'in' ? 'bubble-in' : 'bubble-out'
      } ${className}`}
    >
      {view.text}
      <span
        aria-hidden="true"
        className="absolute bottom-6 h-4 w-4 rotate-45 bg-white ltr:-left-[9px] ltr:border-b-2 ltr:border-l-2 ltr:border-teal-200 rtl:-right-[9px] rtl:border-r-2 rtl:border-t-2 rtl:border-teal-200"
      />
    </div>
  );
}

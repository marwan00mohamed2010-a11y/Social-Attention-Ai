import { ShieldCheck } from 'lucide-react';
import { useI18n } from '../i18n/I18nProvider.jsx';

// Tailwind classes are listed in full so the JIT compiler can see them.
export const TONES = {
  emerald: 'bg-mint-100 text-teal-800 ring-mint-300',
  amber: 'bg-beige-100 text-amber-900 ring-beige-300',
  rose: 'bg-rose-50 text-rose-800 ring-rose-200',
  teal: 'bg-teal-50 text-teal-800 ring-teal-200',
  slate: 'bg-beige-50 text-slate-700 ring-beige-200',
};

export function Card({ className = '', children }) {
  return (
    <section className={`rounded-3xl border border-beige-200 bg-white p-5 shadow-sm ${className}`}>
      {children}
    </section>
  );
}

export function Badge({ tone = 'slate', children, className = '' }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ring-1 ${TONES[tone]} ${className}`}>
      {children}
    </span>
  );
}

export function PrivacyBadge({ className = '' }) {
  const { t } = useI18n();
  return (
    <Badge tone="teal" className={className}>
      <ShieldCheck className="h-4 w-4" aria-hidden="true" />
      {t('common.privacyBadge')}
    </Badge>
  );
}

/** Primary = soft orange, deepening to coral/red-orange while pressed. */
export function Button({ variant = 'primary', className = '', ...props }) {
  const base =
    'inline-flex select-none items-center justify-center gap-2 rounded-2xl px-5 py-3 text-base font-semibold transition duration-150 ease-out focus:outline-none focus-visible:ring-4 active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-50 disabled:active:scale-100';
  const variants = {
    primary:
      'bg-coral-500 text-white shadow-md hover:bg-coral-600 hover:shadow-lg active:bg-coral-700 active:shadow-sm focus-visible:ring-coral-400/60',
    secondary:
      'bg-white text-teal-800 ring-1 ring-beige-300 hover:bg-beige-50 active:bg-beige-100 focus-visible:ring-teal-300',
    ghost: 'text-slate-100 hover:bg-white/10 active:bg-white/20 focus-visible:ring-white/40',
  };
  return <button className={`${base} ${variants[variant]} ${className}`} {...props} />;
}

const KIND = {
  measured: ['kind.measured', 'bg-teal-100 text-teal-800'],
  estimated: ['kind.estimated', 'bg-beige-200 text-amber-900'],
  missing: ['kind.missing', 'bg-slate-200 text-slate-600'],
};

/** Metric tile. `kind` says whether the number is measured, an estimate, or missing/invalid. */
export function Metric({ label, value, unit, hint, kind }) {
  const { t } = useI18n();
  const k = KIND[kind];
  return (
    <Card className="flex flex-col gap-1">
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm font-medium text-slate-500">{label}</p>
        {k && <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${k[1]}`}>{t(k[0])}</span>}
      </div>
      <p className="text-3xl font-bold tabular-nums text-slate-900">
        {value}
        {unit && <span className="ms-1 text-lg font-semibold text-slate-500">{unit}</span>}
      </p>
      {hint && <p className="text-xs text-slate-500">{hint}</p>}
    </Card>
  );
}

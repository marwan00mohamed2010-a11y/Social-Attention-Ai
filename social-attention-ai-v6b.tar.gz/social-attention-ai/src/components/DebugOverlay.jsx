import { useEffect, useRef, useState } from 'react';
import { gazeKey } from '../lib/gazeMath.js';
import { useI18n } from '../i18n/I18nProvider.jsx';
import { ZONE } from '../lib/constants.js';

const W = 320;
const H = 240;

// Draws the mirrored webcam feed, the 478-point mesh, iris rings and gaze vectors.
function drawFrame(ctx, video, frame, live) {
  ctx.clearRect(0, 0, W, H);
  if (video && video.readyState >= 2) {
    ctx.save();
    ctx.translate(W, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, 0, 0, W, H);
    ctx.restore();
  }
  ctx.fillStyle = 'rgba(15,23,42,0.25)';
  ctx.fillRect(0, 0, W, H);
  if (!frame?.faceFound) return;

  const px = (p) => (1 - p.x) * W; // mirrored x
  const py = (p) => p.y * H;
  const lm = frame.landmarks;

  ctx.fillStyle = 'rgba(94,234,212,0.7)';
  for (const p of lm) ctx.fillRect(px(p), py(p), 1.2, 1.2);

  // Iris rings and gaze vectors (eye-corner midpoint → iris centre)
  const eyes = [
    { iris: 468, ring: [469, 470, 471, 472], corners: [33, 133] },
    { iris: 473, ring: [474, 475, 476, 477], corners: [362, 263] },
  ];
  ctx.lineWidth = 1.5;
  for (const eye of eyes) {
    const c = lm[eye.iris];
    const r = Math.hypot((lm[eye.ring[0]].x - c.x) * W, (lm[eye.ring[0]].y - c.y) * H);
    ctx.strokeStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(px(c), py(c), r, 0, Math.PI * 2);
    ctx.stroke();

    const a = lm[eye.corners[0]];
    const b = lm[eye.corners[1]];
    const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
    ctx.strokeStyle = '#f472b6';
    ctx.beginPath();
    ctx.moveTo(px(mid), py(mid));
    ctx.lineTo(px(c), py(c));
    ctx.stroke();
  }

  // Estimated gaze direction: arrow from the nose toward the estimated on-screen gaze point (an ESTIMATE).
  if (live?.faceFound) {
    const n = lm[1];
    const ax = px(n);
    const ay = py(n);
    const bx = ax + (live.x - 0.5) * 140;
    const by = ay + (live.y - 0.5) * 140;
    ctx.strokeStyle = '#fb923c';
    ctx.fillStyle = '#fb923c';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(ax, ay);
    ctx.lineTo(bx, by);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(bx, by, 4, 0, Math.PI * 2);
    ctx.fill();
  }
}

export default function DebugOverlay({ pipeline, liveRef, telemetry }) {
  const { t } = useI18n();
  const canvasRef = useRef(null);
  const lastDrawRef = useRef(0);
  const [snap, setSnap] = useState({ yawDeg: 0, pitchDeg: 0, zone: ZONE.OFF, faceFound: false, conf: 0, gx: 0, gy: 0 });

  useEffect(() => {
    return pipeline.subscribe((frame) => {
      // Throttled to ~15 fps so the debug view never slows the assessment loop.
      if (frame.t - lastDrawRef.current < 66) return;
      lastDrawRef.current = frame.t;
      const c = canvasRef.current;
      if (c) drawFrame(c.getContext('2d'), pipeline.getVideo(), frame, liveRef.current);
    });
  }, [pipeline]);

  useEffect(() => {
    const id = setInterval(() => {
      const live = liveRef.current;
      setSnap({
        yawDeg: pipeline.latestRef.current?.yawDeg ?? 0,
        pitchDeg: pipeline.latestRef.current?.pitchDeg ?? 0,
        zone: live.zone,
        faceFound: live.faceFound,
        conf: live.conf ?? 0,
        gx: live.x,
        gy: live.y,
      });
    }, 200);
    return () => clearInterval(id);
  }, [pipeline, liveRef]);

  return (
    <div dir="ltr" className="pointer-events-none w-80 overflow-hidden rounded-xl bg-slate-900/90 text-xs text-slate-100 shadow-xl ring-1 ring-white/20">
      <canvas ref={canvasRef} width={W} height={H} className="block w-full" role="img" aria-label={t('debug.meshAria')} />
      <div className="grid grid-cols-2 gap-x-3 gap-y-1 p-3 font-mono tabular-nums">
        <span>{t('debug.fps')}: {telemetry.fps}</span>
        <span>{t('debug.latency')}: {telemetry.latencyMs} ms</span>
        <span>{t('debug.yaw')}: {snap.yawDeg.toFixed(1)}°</span>
        <span>{t('debug.pitch')}: {snap.pitchDeg.toFixed(1)}°</span>
        <span>{t('debug.conf')}: {(snap.conf * 100).toFixed(0)}%</span>
        <span>{t('debug.gaze')}: {snap.faceFound ? `${snap.gx.toFixed(2)}, ${snap.gy.toFixed(2)}` : '—'}</span>
        <span className="col-span-2 mt-1 rounded bg-white/10 px-2 py-1 text-center text-sm font-bold">
          {t(gazeKey(snap.faceFound ? snap.zone : ZONE.OFF))}
        </span>
      </div>
    </div>
  );
}

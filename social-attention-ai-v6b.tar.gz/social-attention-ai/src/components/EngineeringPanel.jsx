import { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, Cpu, FileText, FlaskConical, Lock, XCircle } from 'lucide-react';
import { Badge, Button, Card, Metric } from './ui.jsx';
import CatGuide from './CatGuide.jsx';
import { SESSION_MS, SYNTH_TOLERANCE_PTS } from '../lib/constants.js';
import { analyzeSession } from '../lib/metrics.js';
import { generateSynthetic, SYNTHETIC_PROFILES } from '../lib/synthetic.js';
import { externalRequestsSince } from '../lib/perfMonitor.js';
import { useI18n } from '../i18n/I18nProvider.jsx';
import { SKIN_PRESETS } from '../lib/faceStimulus.js';
import { clearLocalStimulus, getLocalStimulus, getSkinTone, setLocalStimulus, setSkinTone, subscribeStimulus } from '../lib/stimulusStore.js';

const fmt = (n, d = 1) => (Number.isFinite(n) ? n.toFixed(d) : '—');

function runSimulation(profileId) {
  const profile = SYNTHETIC_PROFILES[profileId];
  const analysis = analyzeSession(generateSynthetic(profileId), SESSION_MS);
  const pass = analysis.valid && Math.abs(analysis.socialFixationPct - profile.targetPct) <= SYNTH_TOLERANCE_PTS;
  return { profile, analysis, pass };
}

/** Synthetic results live only in this component's state: they are never mixed with real sessions. */
function StimulusSettings() {
  const { t } = useI18n();
  const local = useSyncExternalStore(subscribeStimulus, getLocalStimulus);
  const skin = useSyncExternalStore(subscribeStimulus, getSkinTone);
  const [bad, setBad] = useState(false);
  const inputRef = useRef(null);
  return (
    <Card className="space-y-3">
      <h2 className="text-lg font-bold text-slate-900">{t('eng.stimTitle')}</h2>
      <p className="text-sm text-slate-600">{t('eng.stimBody')}</p>
      <div className="flex flex-wrap items-center gap-3">
        <input
          ref={inputRef}
          type="file"
          accept="image/*,video/mp4,video/webm"
          className="hidden"
          onChange={(e) => {
            const ok = setLocalStimulus(e.target.files?.[0]);
            setBad(!ok);
            e.target.value = '';
          }}
        />
        <Button variant="secondary" onClick={() => inputRef.current?.click()}>{t('eng.stimPick')}</Button>
        {local.url && <Button variant="ghost" onClick={() => { clearLocalStimulus(); setBad(false); }}>{t('eng.stimClear')}</Button>}
        <p className="text-sm text-slate-700" dir="auto">{local.url ? t('eng.stimActive', { n: local.name }) : t('eng.stimNone')}</p>
      </div>
      {bad && <p className="text-sm text-coral-600">{t('eng.stimBadType')}</p>}
      <label className="flex items-center gap-2 text-sm text-slate-700">
        {t('eng.skin')}
        <select className="rounded-lg border border-beige-200 bg-white p-1" value={skin} onChange={(e) => setSkinTone(e.target.value)}>
          {Object.keys(SKIN_PRESETS).map((k) => <option key={k} value={k}>{t(`skin.${k}`)}</option>)}
        </select>
      </label>
      <p className="text-xs text-slate-500">{t('eng.stimConsent')}</p>
    </Card>
  );
}

export default function EngineeringPanel({ pipeline, onBack, onSyntheticReport, onOpenLab }) {
  const { t, isAr } = useI18n();
  const { telemetry, status, streaming, engine, cameraInfo } = pipeline;
  const [external, setExternal] = useState([]);
  const [results, setResults] = useState({});
  const [mem, setMem] = useState(null);
  const [online, setOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const BackIcon = isAr ? ArrowRight : ArrowLeft;

  // Privacy audit and memory sample: refreshed every 2 s.
  useEffect(() => {
    const check = () => {
      setExternal(externalRequestsSince(0) ?? []);
      const m = performance.memory?.usedJSHeapSize; // Chromium only
      setMem(m ? m / 1048576 : null);
      setOnline(navigator.onLine);
    };
    check();
    const id = setInterval(check, 2000);
    return () => clearInterval(id);
  }, []);

  const compliant = external.length === 0;
  const runOne = (id) => setResults((r) => ({ ...r, [id]: runSimulation(id) }));
  const runAll = () => setResults({ typical: runSimulation('typical'), asd: runSimulation('asd') });
  const camText = streaming
    ? `${status.phase} · ${cameraInfo.width}×${cameraInfo.height} · ${engine.delegate || '—'}`
    : t('eng.camOff');

  return (
    <div className="mx-auto max-w-5xl space-y-6 px-4 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-sm font-semibold uppercase tracking-widest text-teal-700">{t('eng.judgeView')}</p>
          <h1 className="text-3xl font-bold text-teal-800">{t('eng.title')}</h1>
        </div>
        <Button variant="secondary" onClick={onBack}><BackIcon className="h-4 w-4" aria-hidden="true" /> {t('common.back')}</Button>
      </div>

      <CatGuide state="idle" size={100} message={t('cat.eng')} />

      <StimulusSettings />

      <Card className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-slate-700">Developer tools: camera capabilities, original-vs-enhanced A/B measurements, calibration diagnostics.</p>
        <Button variant="secondary" onClick={onOpenLab}>Open Vision Lab</Button>
      </Card>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Metric label={t('eng.fps')} value={telemetry.fps} unit="FPS" kind="measured" hint={status.phase === 'ready' ? t('eng.fpsLive') : t('eng.fpsIdle')} />
        <Metric label={t('eng.latency')} value={fmt(telemetry.latencyMs)} unit="ms" kind="measured" hint={t('eng.latencyHint')} />
        <Metric label={t('eng.memory')} value={mem == null ? '—' : fmt(mem, 0)} unit={mem == null ? '' : 'MB'} kind={mem == null ? 'missing' : 'measured'} hint={mem == null ? t('eng.memNA') : 'performance.memory'} />
        <Card className="flex flex-col gap-2">
          <p className="text-sm font-medium text-slate-500">{t('eng.camStatus')}</p>
          <p className="text-sm font-semibold text-slate-900" dir="ltr">{camText}</p>
        </Card>
        <Card className="flex flex-col gap-2">
          <p className="text-sm font-medium text-slate-500">{t('eng.privacy')}</p>
          <Badge tone={compliant ? 'emerald' : 'amber'} className="w-fit">
            {compliant && <Lock className="h-3.5 w-3.5" aria-hidden="true" />}
            {compliant ? t('eng.compliant') : t('eng.externalCount', { n: external.length })}
          </Badge>
          <p className="text-xs text-slate-500">{t('eng.auditNote')}</p>
        </Card>
        <Card className="flex flex-col gap-2">
          <p className="text-sm font-medium text-slate-500">{t('eng.network')}</p>
          <p className="text-xs text-slate-600">{t('eng.networkBody', { s: online ? t('eng.online') : t('eng.offline') })}</p>
        </Card>
      </section>

      <Card className="space-y-3 text-sm text-slate-700">
        <div className="flex items-center gap-2">
          <Cpu className="h-5 w-5 text-teal-700" aria-hidden="true" />
          <h2 className="text-lg font-semibold text-slate-900">{t('eng.archTitle')}</h2>
        </div>
        <ul className="list-disc space-y-1 ps-5">
          <li>{t('eng.arch1')}</li>
          <li>{t('eng.arch2')}</li>
          <li>{t('eng.arch3')}</li>
          <li>{t('eng.arch4')}</li>
        </ul>
      </Card>

      <Card className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <FlaskConical className="h-5 w-5 text-coral-600" aria-hidden="true" />
            <h2 className="text-lg font-semibold text-slate-900">{t('eng.simTitle')}</h2>
            <Badge tone="amber">{t('eng.synthBadge')}</Badge>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={() => runOne('typical')}>{t('eng.runA')}</Button>
            <Button variant="secondary" onClick={() => runOne('asd')}>{t('eng.runB')}</Button>
            <Button onClick={runAll}>{t('eng.runBoth')}</Button>
          </div>
        </div>
        <p className="text-xs text-slate-500">{t('eng.simNote')}</p>

        {Object.keys(results).length === 0 && <p className="rounded-lg bg-beige-50 p-4 text-sm text-slate-500">{t('eng.noSims')}</p>}

        <div className="grid gap-4 md:grid-cols-2">
          {Object.values(results).map(({ profile, analysis, pass }) => (
            <div key={profile.id} className="space-y-2 rounded-2xl border-2 border-dashed border-coral-400 p-4">
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-semibold text-slate-900">{t(profile.labelKey)}</h3>
                <Badge tone={pass ? 'emerald' : 'rose'}>
                  {pass ? <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" /> : <XCircle className="h-3.5 w-3.5" aria-hidden="true" />}
                  {pass ? t('eng.pass') : t('eng.fail')}
                </Badge>
              </div>
              <Badge tone="amber">{t('eng.synthBadge')}</Badge>
              {analysis.valid ? (
                <>
                  <p className="text-xs text-slate-600">{t('eng.check', { t: profile.targetPct, m: fmt(analysis.socialFixationPct, 0) })}</p>
                  <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                    <dt className="text-slate-500">{t('eng.sfr')}</dt><dd className="tabular-nums">{fmt(analysis.socialFixationPct)}%</dd>
                    <dt className="text-slate-500">{t('eng.shiftsMin')}</dt><dd className="tabular-nums">{fmt(analysis.shiftsPerMin)}</dd>
                    <dt className="text-slate-500">{t('eng.avgFix')}</dt><dd className="tabular-nums">{fmt(analysis.avgFixationMs, 0)} ms</dd>
                    <dt className="text-slate-500">{t('eng.offScreen')}</dt><dd className="tabular-nums">{fmt(analysis.offScreenPct)}%</dd>
                  </dl>
                </>
              ) : (
                <p className="text-sm text-rose-700">{t('report.insufficientBody', { s: fmt(analysis.validMs / 1000) })}</p>
              )}
              <Button variant="secondary" className="w-full" onClick={() => onSyntheticReport(profile.id)}>
                <FileText className="h-4 w-4" aria-hidden="true" /> {t('eng.viewReport')}
              </Button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

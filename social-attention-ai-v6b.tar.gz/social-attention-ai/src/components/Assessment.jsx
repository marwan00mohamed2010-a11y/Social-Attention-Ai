import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { Bug, X } from 'lucide-react';
import { COUNTDOWN_S, SESSION_MS, ZONE } from '../lib/constants.js';
import { Ema, classifyGaze, gazeKey, mapToScreen } from '../lib/gazeMath.js';
import { useAnimatedCanvas } from '../hooks/useAnimatedCanvas.js';
import { useI18n } from '../i18n/I18nProvider.jsx';
import { drawGeometric } from './stimuli.js';
import { drawHumanFace } from '../lib/faceStimulus.js';
import { getLocalStimulus, getSkinTone, subscribeStimulus } from '../lib/stimulusStore.js';
import DebugOverlay from './DebugOverlay.jsx';
import CatGuide from './CatGuide.jsx';

// Optional licensed research clips. Drop social.mp4 / nonsocial.mp4 into public/stimuli/ (see README there).
// If a file is missing, the generated canvas animation is used. Generated animations are NOT recorded videos.
function useClip(url) {
  const [ok, setOk] = useState(false);
  useEffect(() => {
    let live = true;
    fetch(url, { method: 'HEAD', cache: 'no-store' })
      .then((r) => live && setOk(r.ok && (r.headers.get('content-type') || '').startsWith('video/')))
      .catch(() => {});
    return () => { live = false; };
  }, [url]);
  return ok;
}

function ClipVideo({ src, label }) {
  return (
    <div className="absolute inset-0 bg-black" role="img" aria-label={label}>
      <video src={src} autoPlay loop muted playsInline className="h-full w-full object-cover" />
    </div>
  );
}

/** Local photo: cover-fit with a very gentle tilt/nod so it is not a frozen frame. */
function PhotoStimulus({ src, label }) {
  const imgRef = useRef(null);
  useEffect(() => {
    const img = new Image();
    img.src = src;
    imgRef.current = img;
  }, [src]);
  const draw = useCallback((ctx, w, h, t) => {
    const img = imgRef.current;
    ctx.fillStyle = '#222';
    ctx.fillRect(0, 0, w, h);
    if (!img?.complete || !img.naturalWidth) return;
    const sc = Math.max(w / img.naturalWidth, h / img.naturalHeight) * 1.04;
    ctx.save();
    ctx.translate(w / 2, h / 2 + Math.sin(t * 0.8) * h * 0.004);
    ctx.rotate(Math.sin(t * 0.45) * 0.01);
    ctx.drawImage(img, (-img.naturalWidth * sc) / 2, (-img.naturalHeight * sc) / 2, img.naturalWidth * sc, img.naturalHeight * sc);
    ctx.restore();
  }, []);
  return <StimulusCanvas draw={draw} label={label} />;
}

function StimulusCanvas({ draw, label }) {
  const ref = useAnimatedCanvas(draw);
  return (
    <div className="absolute inset-0" role="img" aria-label={label}>
      <canvas ref={ref} className="block" />
    </div>
  );
}

export default function Assessment({ pipeline, calibration, onComplete, onAbort }) {
  const { t } = useI18n();
  const [phase, setPhase] = useState('countdown'); // countdown | running
  const [remaining, setRemaining] = useState(COUNTDOWN_S);
  const [elapsed, setElapsed] = useState(0);
  const [zone, setZone] = useState(ZONE.OFF);
  const [debug, setDebug] = useState(false);

  const local = useSyncExternalStore(subscribeStimulus, getLocalStimulus);
  const skinTone = useSyncExternalStore(subscribeStimulus, getSkinTone);
  const drawFace = useCallback((ctx, w, h, t) => drawHumanFace(ctx, w, h, t, { skin: skinTone }), [skinTone]);
  const socialClip = useClip('/stimuli/social.mp4');
  const nonSocialClip = useClip('/stimuli/nonsocial.mp4');
  const sourceRef = useRef('generated');
  // Priority for the LEFT half: operator-loaded local file > public/stimuli/social.mp4 > generated human face.
  sourceRef.current = local.url ? 'local-file' : socialClip || nonSocialClip ? 'clip' : 'generated';
  const liveRef = useRef({ zone: ZONE.OFF, x: 0.5, y: 0.5, yawDeg: 0, pitchDeg: 0, faceFound: false, conf: 0 });
  const sessionRef = useRef({ active: false, t0: 0, samples: [], startedAt: 0 });
  const emaRef = useRef(new Ema(0.35));
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  // Per-frame gaze pipeline: calibrated mapping → smoothing → zone → sample log.
  useEffect(() => {
    return pipeline.subscribe((frame) => {
      const live = liveRef.current;
      if (!frame.faceFound || !calibration) {
        emaRef.current.reset();
        live.zone = ZONE.OFF;
        live.faceFound = false;
        live.conf = 0;
      } else {
        const s = emaRef.current.push(mapToScreen(calibration, frame));
        live.x = s.x;
        live.y = s.y;
        live.zone = classifyGaze(s.x, s.y, true);
        live.faceFound = true;
        live.yawDeg = frame.yawDeg;
        live.pitchDeg = frame.pitchDeg;
        live.conf = frame.conf ?? 0;
      }
      const ses = sessionRef.current;
      if (ses.active) {
        const t = performance.now() - ses.t0;
        if (t >= 0 && t <= SESSION_MS) {
          ses.samples.push({ t: Math.round(t), zone: live.zone, x: live.x, y: live.y, conf: live.conf });
        }
      }
    });
  }, [pipeline, calibration]);

  // HUD zone readout at 10 Hz, active throughout the countdown and the session.
  useEffect(() => {
    const id = setInterval(() => setZone(liveRef.current.zone), 100);
    return () => clearInterval(id);
  }, []);

  // Countdown
  useEffect(() => {
    if (phase !== 'countdown') return;
    if (remaining <= 0) {
      setPhase('running');
      return;
    }
    const id = setTimeout(() => setRemaining((r) => r - 1), 1000);
    return () => clearTimeout(id);
  }, [phase, remaining]);

  // 15-second recording window
  useEffect(() => {
    if (phase !== 'running') return;
    const ses = sessionRef.current;
    ses.samples = [];
    ses.t0 = performance.now();
    ses.startedAt = performance.now();
    ses.active = true;

    const ui = setInterval(() => setElapsed(Math.min(SESSION_MS, performance.now() - ses.t0)), 100);

    const end = setTimeout(() => {
      ses.active = false;
      clearInterval(ui);
      onCompleteRef.current({
        samples: ses.samples.slice(),
        durationMs: SESSION_MS,
        sessionStartedAt: ses.startedAt,
        stimulusSource: sourceRef.current,
      });
    }, SESSION_MS);

    return () => {
      ses.active = false;
      clearInterval(ui);
      clearTimeout(end);
    };
  }, [phase]);

  const offScreen = phase === 'running' && zone === ZONE.OFF;

  return (
    // Physical LTR layout keeps the social stimulus on the left in every language.
    <div dir="ltr" className="fixed inset-0 z-40 select-none overflow-hidden bg-slate-950 text-white">
      <div className="absolute inset-0 flex">
        <div className="relative h-full w-1/2">
          {local.url && local.kind === 'video' ? <ClipVideo src={local.url} label={t('assess.socialAria')} />
            : local.url && local.kind === 'image' ? <PhotoStimulus src={local.url} label={t('assess.socialAria')} />
              : socialClip ? <ClipVideo src="/stimuli/social.mp4" label={t('assess.socialAria')} />
                : <StimulusCanvas draw={drawFace} label={t('assess.socialAria')} />}
        </div>
        <div className="relative h-full w-1/2">
          {nonSocialClip ? <ClipVideo src="/stimuli/nonsocial.mp4" label={t('assess.nonSocialAria')} /> : <StimulusCanvas draw={drawGeometric} label={t('assess.nonSocialAria')} />}
        </div>
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-1/2 w-0.5 -translate-x-1/2 bg-white/90" aria-hidden="true" />

      {/* HUD */}
      <div className="absolute inset-x-0 top-0 z-30 flex items-center justify-between gap-3 p-3">
        <div className="flex flex-wrap items-center gap-2 rounded-full bg-black/70 px-4 py-2 text-sm font-semibold">
          {phase === 'countdown' ? (
            <span>{t('assess.startingIn', { n: remaining })}</span>
          ) : (
            <span className="tabular-nums">
              {(elapsed / 1000).toFixed(1)} / {SESSION_MS / 1000} s
            </span>
          )}
          <span className="rounded-full bg-white/15 px-3 py-0.5 font-mono text-xs">{t(gazeKey(zone))}</span>
        </div>
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            type="button"
            onClick={() => setDebug((d) => !d)}
            aria-pressed={debug}
            className="flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-2 text-xs font-semibold hover:bg-black/90 focus:outline-none focus-visible:ring-4 focus-visible:ring-white/50"
          >
            <Bug className="h-4 w-4" aria-hidden="true" /> {debug ? t('assess.debugOn') : t('assess.debugOff')}
          </button>
          <button
            type="button"
            onClick={onAbort}
            className="flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-2 text-xs font-semibold hover:bg-black/90 focus:outline-none focus-visible:ring-4 focus-visible:ring-white/50"
          >
            <X className="h-4 w-4" aria-hidden="true" /> {t('assess.cancel')}
          </button>
        </div>
      </div>

      {offScreen && (
        <div role="status" className="absolute left-1/2 top-20 z-30 -translate-x-1/2 rounded-lg bg-amber-500/90 px-4 py-2 text-sm font-semibold text-slate-900">
          {t('assess.lost')}
        </div>
      )}

      {phase === 'countdown' && (
        <div className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center gap-6">
          <span className="rounded-full bg-black/60 px-10 py-6 text-7xl font-black tabular-nums">
            {remaining > 0 ? remaining : t('assess.go')}
          </span>
          {/* The cat only appears BEFORE recording starts, so it never competes with the stimuli. */}
          <div className="rounded-3xl bg-teal-900/80 p-3">
            <CatGuide state="encouraging" size={110} message={t('cat.assess')} />
          </div>
        </div>
      )}

      <div className="absolute inset-x-0 bottom-0 z-30 h-1.5 bg-white/20">
        <div className="h-full bg-teal-300 transition-[width] duration-100" style={{ width: `${(elapsed / SESSION_MS) * 100}%` }} />
      </div>

      {debug && (
        <div className="absolute bottom-4 right-4 z-40">
          <DebugOverlay pipeline={pipeline} liveRef={liveRef} telemetry={pipeline.telemetry} />
        </div>
      )}
    </div>
  );
}

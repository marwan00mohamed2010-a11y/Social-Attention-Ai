import Mascot from './Mascot.jsx';
import SpeechBubble from './SpeechBubble.jsx';
import { useI18n } from '../i18n/I18nProvider.jsx';

/** The cat with its speech bubble beside it. `dir` is set explicitly so it also works inside LTR-forced screens. */
export default function CatGuide({ state = 'idle', message, size = 150, className = '' }) {
  const { dir } = useI18n();
  return (
    <div dir={dir} className={`flex items-end gap-3 ${className}`}>
      <Mascot state={state} size={size} className="shrink-0" />
      <SpeechBubble text={message} className="mb-10" />
    </div>
  );
}

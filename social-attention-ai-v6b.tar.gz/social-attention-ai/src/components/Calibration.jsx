import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Star } from 'lucide-react';
import { CALIB, CALIB_TARGETS, VALIDATION_TARGETS, QC } from '../lib/constants.js';
import { calibrationDiagnostics, calibrationLooError, fitCalibration, validationError } from '../lib/gazeMath.js';
import { useI18n } from '../i18n/I18nProvider.jsx';
import { Button } from './ui.jsx';
import CatGuide from './CatGuide.jsx';

const KEYS = ['irisX', 'irisY', 'yawDeg', 'pitchDeg'];
const median = (a) => {
  const b = [...a].sort((x, y) => x - y);
  const m = b.length >> 1;
  return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2;
};
// Per-target summary uses the median, which ignores the occasional blink / glance / tracking glitch frame.
const summarise = (arr) => Object.fromEntries(KEYS.map((k) => [k, median(arr.map((s) => s[k]))]));
const ALL_TARGETS = [...CALIB_TARGETS, ...VALIDATION_TARGETS];

export default function Calibration({ pipeline, onComplete, onBack }) {
  const { t, isAr } = useI18n();
  const [phase, setPhase] = useState('run'); // run | unstable
  const [idx, setIdx] = useState(0);
  const [progress, setProgress] = useState(0);
  const [warning, setWarning] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [looErr, setLooErr] = useState(0);

  const bufRef = useRef([]);
  const doneRef = useRef([]);
  const rawRef = useRef([]);
  const valRef = useRef([]);
  const modelRef = useRef(null);
  const startRef = useRef(0);
  const rejectedRef = useRef(0);
  const activeRef = useRef(false);
  const target = ALL_TARGETS[idx];
  const BackIcon = isAr ? ArrowRight : ArrowLeft;

  // Collect iris + head-pose samples only after the settle period and only when a face is present.
  useEffect(() => {
    return pipeline.subscribe((f) => {
      if (!activeRef.current || !f.faceFound) return;
      if (f.eyeValid === false) {
        rejectedRef.current += 1; // blink / eye not visible: not usable for calibration
        return;
      }
      if (performance.now() - startRef.current < CALIB.settleMs) return;
      bufRef.current.push({ irisX: f.irisX, irisY: f.irisY, yawDeg: f.yawDeg, pitchDeg: f.pitchDeg });
    });
  }, [pipeline]);

  // One 2-second window per target. A retry is triggered if too few face samples were captured.
  useEffect(() => {
    if (phase !== 'run') return undefined;
    bufRef.current = [];
    rejectedRef.current = 0;
    startRef.current = performance.now();
    activeRef.current = true;
    setProgress(0);

    const tick = setInterval(() => {
      setProgress(Math.min(1, (performance.now() - startRef.current) / CALIB.totalMs));
    }, 50);

    const timer = setTimeout(() => {
      clearInterval(tick);
      activeRef.current = false;
      const samples = bufRef.current;
      if (samples.length < CALIB.minSamples) {
        setWarning(true);
        setAttempt((a) => a + 1);
        return;
      }
      setWarning(false);
      const pt = { ...summarise(samples), x: target.x, y: target.y, n: samples.length, rejected: rejectedRef.current };
      if (target.validation) valRef.current = [...valRef.current, pt];
      else doneRef.current = [...doneRef.current, pt];
      rawRef.current = [...rawRef.current, ...samples.map((q) => ({ target: target.id, tx: target.x, ty: target.y, validation: !!target.validation, ...q }))];
      if (idx + 1 < ALL_TARGETS.length) {
        setIdx(idx + 1);
        return;
      }
      // Fit on the five targets, then judge on the four held-out interior targets (never used in the fit).
      const points = doneRef.current;
      const model = fitCalibration(points);
      model.looError = calibrationLooError(points, model.ridge);
      const val = validationError(model, valRef.current);
      model.validationError = val ? val.mean : null;
      model.validationPoints = val ? val.per : [];
      model.diagnostics = calibrationDiagnostics(points, valRef.current);
      model.valPoints = valRef.current;
      modelRef.current = model;
      // The gate uses the honest held-out error when available. The 25% threshold is NOT relaxed.
      const gateErr = model.validationError ?? model.looError;
      model.gateError = gateErr;
      if (gateErr != null && gateErr > QC.maxCalibErr) {
        setLooErr(gateErr);
        setPhase('unstable');
      } else {
        onComplete(model, rawRef.current);
      }
    }, CALIB.totalMs);

    return () => {
      clearInterval(tick);
      clearTimeout(timer);
      activeRef.current = false;
    };
    // target is derived from idx; attempt forces a retry of the same point.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idx, attempt, phase]);

  const recalibrate = () => {
    doneRef.current = [];
    valRef.current = [];
    rawRef.current = [];
    setWarning(false);
    setIdx(0);
    setAttempt((a) => a + 1);
    setPhase('run');
  };

  if (phase === 'unstable') {
    return (
      <div className="fixed inset-0 z-40 flex items-center justify-center bg-cream p-4">
        <div className="w-full max-w-xl space-y-5 rounded-3xl border border-beige-200 bg-white p-6 shadow-md">
          <CatGuide state="error" size={150} message={t('cat.calibUnstable')} className="justify-center" />
          <h2 className="text-xl font-bold text-slate-900">{t('calib.unstableTitle')}</h2>
          <p className="text-slate-600">{t('calib.unstableBody', { v: Math.round(looErr * 100) })}</p>
          <div className="flex flex-wrap gap-3">
            <Button onClick={recalibrate}>{t('calib.recalibrate')}</Button>
            <Button variant="secondary" onClick={() => onComplete(modelRef.current, rawRef.current)}>
              {t('calib.continueAnyway')}
            </Button>
            <Button variant="secondary" onClick={onBack}>{t('common.back')}</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-40 overflow-hidden bg-gradient-to-br from-teal-900 via-teal-800 to-teal-900 text-white">
      <header className="absolute inset-x-0 top-0 z-10 space-y-1 p-6 text-center">
        <p className="text-sm font-semibold uppercase tracking-widest text-mint-300">{target.validation ? t('calib.stepCheck', { n: idx + 1 - CALIB_TARGETS.length }) : t('calib.step', { n: idx + 1 })}</p>
        <h2 className="text-2xl font-bold">{t('calib.title')}</h2>
        <p className="text-base text-teal-100">{t('calib.target', { label: t(`target.${target.id}`) })}</p>
      </header>

      {/* Targets use physical (LTR) positions regardless of language, so calibration maps to the real screen. */}
      <div
        className="absolute"
        dir="ltr"
        style={{ left: `${target.x * 100}%`, top: `${target.y * 100}%`, transform: 'translate(-50%, -50%)' }}
        aria-hidden="true"
      >
        <div className="relative flex h-28 w-28 items-center justify-center">
          <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90">
            <circle cx="50" cy="50" r="46" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="6" />
            <circle
              cx="50" cy="50" r="46" fill="none" stroke="#93d9c0" strokeWidth="6" strokeLinecap="round"
              pathLength="100" strokeDasharray="100" strokeDashoffset={100 - progress * 100}
            />
          </svg>
          <Star className="h-12 w-12 animate-pulse fill-amber-300 text-amber-300" />
        </div>
      </div>

      {/* The cat sits bottom-centre, away from the five calibration targets. */}
      <div dir="ltr" className="absolute inset-x-0 bottom-3 flex justify-center">
        <CatGuide state={warning ? 'error' : 'explaining'} size={96} message={warning ? t('cat.calibRetry') : t('cat.calib')} />
      </div>

      <footer className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-4 p-6">
        <Button variant="ghost" onClick={onBack}>
          <BackIcon className="h-4 w-4" aria-hidden="true" /> {t('common.back')}
        </Button>
        <p className="hidden text-sm text-teal-100 sm:block">{t('calib.note')}</p>
      </footer>
    </div>
  );
}

import { useI18n } from '../i18n/I18nProvider.jsx';

const OPTIONS = [
  { code: 'en', label: 'EN' },
  { code: 'ar', label: 'عربي' },
];

/** Segmented EN | عربي switch for the top navigation bar. */
export default function LanguageToggle() {
  const { lang, setLang, t } = useI18n();
  return (
    <div
      role="group"
      aria-label={t('common.langSwitch')}
      className="inline-flex overflow-hidden rounded-full bg-white text-sm font-semibold ring-1 ring-slate-300"
    >
      {OPTIONS.map((opt, i) => {
        const active = lang === opt.code;
        return (
          <button
            key={opt.code}
            type="button"
            lang={opt.code}
            aria-pressed={active}
            onClick={() => setLang(opt.code)}
            className={`px-3.5 py-1.5 transition focus:outline-none focus-visible:ring-4 focus-visible:ring-teal-300 ${
              active ? 'bg-teal-700 text-white' : 'text-slate-700 hover:bg-slate-50'
            } ${i > 0 ? 'border-s border-slate-300' : ''}`}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}

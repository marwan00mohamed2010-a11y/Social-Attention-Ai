import { useEffect, useRef, useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button, Card } from './ui.jsx';
import { createFaceLandmarker } from '../lib/visionEngine.js';
import { LIGHT_LABELS, compareAB, recommendByLighting, resultsToCsv, runMeasurement } from '../lib/abHarness.js';
import { CANDIDATE_CONFIGS, controlSupport, exposureAssist } from '../lib/cameraCaps.js';
import { downloadText } from '../lib/exportUtils.js';

// Developer-only (English). Every number shown here is measured from real frames on this device.
// Nothing is estimated from a model of the camera, and nothing is pre-filled.
const f1 = (v, d = 1) => (v == null || !Number.isFinite(v) ? '—' : v.toFixed(d));
const f3 = (v) => (v == null || !Number.isFinite(v) ? '—' : v.toFixed(4));

function StatsTable({ A, B }) {
  const rows = [
    ['Face detected (% frames)', 'faceSuccessPct', f1],
    ['Eye landmarks usable (% of face frames)', 'eyeAvailPct', f1],
    ['Valid tracking (% all frames)', 'validTrackingPct', f1],
    ['Iris jitter (median step, lower=steadier)', 'irisJitter', f3],
    ['Landmark jitter (median px)', 'landmarkJitterPx', f3],
    ['Mean latency (ms)', 'meanLatencyMs', f1],
    ['Throughput (FPS, processing-bound)', 'throughputFps', f1],
  ];
  return (
    <table className="w-full text-sm" dir="ltr">
      <thead><tr className="text-left text-slate-500"><th className="py-1">Metric</th><th>A original</th>{B && <th>B enhanced</th>}</tr></thead>
      <tbody>
        {rows.map(([label, k, fn]) => (
          <tr key={k} className="border-t border-beige-100"><td className="py-1 pr-2">{label}</td><td>{fn(A?.[k])}</td>{B && <td>{fn(B?.[k])}</td>}</tr>
        ))}
      </tbody>
    </table>
  );
}

export default function VisionLab({ pipeline, calibration, onBack }) {
  const { streaming, camCaps, cameraInfo, enhanceMode, setEnhanceMode } = pipeline;
  const [lighting, setLighting] = useState('normal');
  const [frames, setFrames] = useState(120);
  const [busy, setBusy] = useState('');
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState([]);
  const [log, setLog] = useState('');
  const lmRef = useRef({ A: null, B: null });
  const signalRef = useRef({ cancelled: false });

  useEffect(() => () => {
    signalRef.current.cancelled = true;
    pipeline.pausedRef.current = false;
    lmRef.current.A?.close(); lmRef.current.B?.close();
  }, [pipeline]);

  const ensureLandmarkers = async (needB) => {
    if (!lmRef.current.A) lmRef.current.A = await createFaceLandmarker();
    if (needB && !lmRef.current.B) lmRef.current.B = await createFaceLandmarker();
  };

  const withRun = async (name, fn) => {
    if (busy) return;
    signalRef.current = { cancelled: false };
    setBusy(name); setProgress(0); setLog('');
    pipeline.pausedRef.current = true; // live loop is paused so it does not compete for the CPU/GPU
    try { await fn(); } catch (e) { setLog(`Error: ${e?.message ?? e}`); } finally { pipeline.pausedRef.current = false; setBusy(''); }
  };

  const runAB = () => withRun('ab', async () => {
    await ensureLandmarkers(true);
    const video = pipeline.getVideo();
    const r = await runMeasurement({ video, lmA: lmRef.current.A, lmB: lmRef.current.B, frames, onProgress: setProgress, signal: signalRef.current });
    setResults((x) => [...x, { time: new Date().toISOString(), kind: 'ab', lighting, config: `${cameraInfo.width}x${cameraInfo.height}`, ...r }]);
  });

  const runSweep = () => withRun('sweep', async () => {
    await ensureLandmarkers(false);
    const prev = { width: cameraInfo.width, height: cameraInfo.height };
    for (const cfg of CANDIDATE_CONFIGS) {
      if (signalRef.current.cancelled) break;
      setLog(`Testing ${cfg.id}…`);
      await pipeline.applyCameraConfig(cfg);
      await new Promise((r) => setTimeout(r, 1200)); // let exposure settle
      const track = pipeline.getTrack();
      const st = track?.getSettings?.() ?? {};
      const r = await runMeasurement({ video: pipeline.getVideo(), lmA: lmRef.current.A, frames: 60, signal: signalRef.current, onProgress: setProgress });
      setResults((x) => [...x, { time: new Date().toISOString(), kind: 'config', lighting, config: `${cfg.id} -> actual ${st.width}x${st.height}@${st.frameRate ?? '?'}`, ...r, B: null }]);
    }
    await pipeline.applyCameraConfig(prev.width ? { width: prev.width, height: prev.height } : null);
    setLog('Sweep finished. Camera returned to the previous size.');
  });

  const runAssist = () => withRun('assist', async () => {
    const track = pipeline.getTrack();
    const r = await exposureAssist(track, camCaps, () => pipeline.lightingRef.current.stats?.p50 ?? 0);
    setLog(`Exposure assist: ${JSON.stringify(r)}`);
  });

  const recordCalibration = () => {
    if (!calibration) return;
    setResults((x) => [...x, {
      time: new Date().toISOString(), kind: 'calibration', lighting, config: `enhance=${enhanceMode}`,
      calibration: { validationError: calibration.validationError, looError: calibration.looError, inSample: calibration.diagnostics?.errors?.inSample, ridge: calibration.ridge },
    }]);
  };

  const sup = camCaps ? controlSupport(camCaps) : null;
  const rec = recommendByLighting(results);
  const D = calibration?.diagnostics;

  return (
    <div className="mx-auto max-w-5xl space-y-5 px-4 py-8" dir="ltr">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold uppercase tracking-widest text-teal-700">Developer only</p>
          <h1 className="text-3xl font-bold text-teal-800">Vision Lab</h1>
          <p className="text-sm text-slate-600">Measures this camera and this lighting on real frames. Nothing here is a validated accuracy figure.</p>
        </div>
        <Button variant="secondary" onClick={onBack}><ArrowLeft className="h-4 w-4" /> Back</Button>
      </div>

      {!streaming && (
        <Card><p className="mb-3 text-sm">The camera is not running.</p><Button onClick={() => pipeline.start()}>Start camera</Button></Card>
      )}

      <Card className="space-y-2">
        <h2 className="font-semibold">Camera diagnostics</h2>
        <p className="text-sm">{cameraInfo.label || '—'} · actual {cameraInfo.width}×{cameraInfo.height} @ {cameraInfo.frameRate || '?'} fps</p>
        {sup && (
          <ul className="text-sm text-slate-700">
            {Object.entries(sup).map(([k, v]) => <li key={k}><b>{k}</b>: {v == null ? 'not reported (not controllable)' : JSON.stringify(v)}</li>)}
          </ul>
        )}
        <details><summary className="cursor-pointer text-sm text-teal-700">Raw getSupportedConstraints / getCapabilities / getSettings</summary>
          <pre className="max-h-64 overflow-auto rounded bg-beige-100 p-2 text-xs">{JSON.stringify(camCaps, null, 2)}</pre>
        </details>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" disabled={!streaming || !!busy || !sup?.exposureCompensation} onClick={runAssist}>One-shot exposure assist</Button>
          <Button variant="secondary" disabled={!streaming || !!busy} onClick={runSweep}>Compare resolution/fps configs</Button>
        </div>
        {sup && !sup.exposureCompensation && <p className="text-xs text-slate-500">Exposure compensation is not reported by this camera, so the assist is disabled. Nothing is forced.</p>}
      </Card>

      <Card className="space-y-3">
        <h2 className="font-semibold">A/B: original vs enhanced → MediaPipe (same frames)</h2>
        <p className="text-sm text-slate-600">Hold still, look at the screen centre, set the lighting label to match the room, then run. Repeat per lighting condition (≥2 runs each).</p>
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <label>Lighting <select className="rounded border p-1" value={lighting} onChange={(e) => setLighting(e.target.value)}>{LIGHT_LABELS.map((l) => <option key={l}>{l}</option>)}</select></label>
          <label>Frames <input type="number" min="30" max="400" className="w-20 rounded border p-1" value={frames} onChange={(e) => setFrames(Number(e.target.value) || 120)} /></label>
          <Button disabled={!streaming || !!busy} onClick={runAB}>{busy === 'ab' ? `Running ${Math.round(progress * 100)}%` : 'Run A/B'}</Button>
          {busy && <Button variant="secondary" onClick={() => { signalRef.current.cancelled = true; }}>Stop</Button>}
        </div>
        <label className="text-sm">Live pipeline enhancement:{' '}
          <select className="rounded border p-1" value={enhanceMode} onChange={(e) => setEnhanceMode(e.target.value)}>
            <option value="off">off (original) — default</option><option value="auto">auto (dark frames only)</option><option value="on">always on</option>
          </select>
        </label>
        {log && <p className="text-sm text-slate-700">{log}</p>}
      </Card>

      {calibration && (
        <Card className="space-y-2">
          <h2 className="font-semibold">Last calibration diagnostics</h2>
          <p className="text-sm">Held-out validation error: <b>{f1((calibration.validationError ?? NaN) * 100)}%</b> · LOO (extrapolating): {f1((calibration.looError ?? NaN) * 100)}% · in-sample: {f1((D?.errors?.inSample ?? NaN) * 100)}% · ridge λ={calibration.ridge}</p>
          {D && (
            <div className="text-xs text-slate-700">
              <p>Feature ranges across targets — irisX {f3(D.ranges.irisX)}, irisY {f3(D.ranges.irisY)}, yaw {f1(D.ranges.yawDeg)}°, pitch {f1(D.ranges.pitchDeg)}°</p>
              <p>corr(irisX,targetX) {f1(D.corr.irisX_vs_targetX, 2)} · corr(irisY,targetY) {f1(D.corr.irisY_vs_targetY, 2)} · corr(irisX,yaw) {f1(D.corr.irisX_vs_yaw, 2)}</p>
              <p>Validation error by feature set — both {f1((D.subsets.both.validation ?? NaN) * 100)}%, iris only {f1((D.subsets.irisOnly.validation ?? NaN) * 100)}%, pose only {f1((D.subsets.poseOnly.validation ?? NaN) * 100)}%</p>
            </div>
          )}
          <Button variant="secondary" onClick={recordCalibration}>Record to results (label: {lighting}, enhance={enhanceMode})</Button>
        </Card>
      )}

      <Card className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">Recorded results ({results.length})</h2>
          <div className="flex gap-2">
            <Button variant="secondary" disabled={!results.length} onClick={() => downloadText('vision-lab.json', JSON.stringify(results, null, 2), 'application/json')}>JSON</Button>
            <Button variant="secondary" disabled={!results.length} onClick={() => downloadText('vision-lab.csv', resultsToCsv(results))}>CSV</Button>
            <Button variant="ghost" disabled={!results.length} onClick={() => setResults([])}>Clear</Button>
          </div>
        </div>
        {!results.length && <p className="text-sm text-slate-500">No measurements yet. Nothing is shown until you record real runs.</p>}
        {results.map((r, i) => (
          <div key={i} className="rounded-xl border border-beige-200 p-3">
            <p className="text-sm font-semibold">{r.kind} · lighting: {r.lighting} · {r.config}{r.medianLuma != null ? ` · median luma ${f1(r.medianLuma, 0)}` : ''}</p>
            {r.kind === 'calibration'
              ? <p className="text-sm">validation {f1((r.calibration.validationError ?? NaN) * 100)}% · LOO {f1((r.calibration.looError ?? NaN) * 100)}%</p>
              : <StatsTable A={r.A} B={r.B} />}
            {r.kind === 'ab' && (() => { const c = compareAB(r.A, r.B); return <p className="mt-1 text-sm text-teal-800">Verdict: {c.verdict} ({c.reasons.join('; ')})</p>; })()}
          </div>
        ))}
        {Object.keys(rec).length > 0 && (
          <div className="rounded-xl bg-mint-100 p-3 text-sm">
            <p className="font-semibold">Evidence-based recommendation per lighting condition</p>
            {Object.entries(rec).map(([k, v]) => <p key={k}>{k}: <b>{v.recommendation}</b> — {v.note}</p>)}
            <p className="mt-1 text-xs text-slate-600">Rule: enhancement is recommended only if every run in that condition shows ≥5 pts more valid tracking, no worse iris jitter, and ≥30 FPS.</p>
          </div>
        )}
      </Card>
    </div>
  );
}

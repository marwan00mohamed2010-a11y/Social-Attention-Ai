// Self-contained canvas stimulus for the NON-social (right) half. The social face lives in lib/faceStimulus.js.

/** Non-social stimulus: hypnotic rotating polygons and orbiting dots. */
export function drawGeometric(ctx, w, h, t) {
  ctx.fillStyle = '#0b1020';
  ctx.fillRect(0, 0, w, h);

  const s = Math.min(w, h);
  const cx = w / 2;
  const cy = h / 2;

  for (let i = 0; i < 12; i++) {
    const radius = ((i + 1) * s) / 26;
    const sides = 3 + (i % 5);
    const rot = t * (0.6 + i * 0.05) * (i % 2 ? 1 : -1);
    ctx.strokeStyle = `hsl(${(t * 40 + i * 30) % 360}, 90%, 60%)`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let k = 0; k <= sides; k++) {
      const a = rot + (k / sides) * Math.PI * 2;
      const px = cx + Math.cos(a) * radius;
      const py = cy + Math.sin(a) * radius;
      if (k === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.stroke();
  }

  for (let k = 0; k < 48; k++) {
    const a = (k / 48) * Math.PI * 2 + t * 1.2;
    const rad = (Math.sin(k * 0.5 + t * 2) * 0.5 + 0.5) * s * 0.45;
    ctx.fillStyle = `hsl(${(k * 7 + t * 50) % 360}, 95%, 65%)`;
    ctx.beginPath();
    ctx.arc(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad, s * 0.008, 0, Math.PI * 2);
    ctx.fill();
  }
}

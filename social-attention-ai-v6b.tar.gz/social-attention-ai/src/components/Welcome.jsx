// Pre-assessment camera check. Every check is verified from real data; if it cannot be verified it says so.
import { useEffect, useRef, useState } from 'react';
import { AlertTriangle, Camera, CheckCircle2, HelpCircle, Loader2 } from 'lucide-react';
import { Button, Card, TONES } from './ui.jsx';
import CatGuide from './CatGuide.jsx';
import { useI18n } from '../i18n/I18nProvider.jsx';
import { computeGuidance, GUIDE } from '../lib/guidance.js';

/** status: 'ok' | 'bad' | 'unknown' | 'idle' */
function CheckRow({ status, label, detail }) {
  const map = {
    ok: [CheckCircle2, 'text-emerald-600'],
    bad: [AlertTriangle, 'text-amber-600'],
    unknown: [HelpCircle, 'text-slate-400'],
    idle: [HelpCircle, 'text-slate-300'],
    busy: [Loader2, 'text-slate-400 animate-spin'],
  };
  const [Icon, tone] = map[status];
  return (
    <li className="flex items-start gap-3 py-2">
      <Icon className={`mt-0.5 h-5 w-5 shrink-0 ${tone}`} aria-hidden="true" />
      <div>
        <p className="font-medium text-slate-800">{label}</p>
        {detail && <p className="text-sm text-slate-500">{detail}</p>}
      </div>
    </li>
  );
}

// Verdict comes from MEASURED tracking evidence (eye validity + iris steadiness), not from brightness alone:
// a dark scene that still tracks well passes, and a bright scene with unreliable eyes does not.
function lightStatus(L, Q) {
  if (!L.ready || !Q || Q.level === 'measuring') return 'unknown';
  if (Q.level === 'ok') return 'ok';
  if (L.backlit) return 'backlit';
  if (Q.reasons.includes('dark')) return 'dark';
  if (Q.reasons.includes('bright') || Q.reasons.includes('clipped')) return 'bright';
  return 'weak';
}

/**
 * Live preview: a real <video> element that shows the camera stream directly.
 * The MediaStream is taken from the pipeline's source video and attached in an effect, so the preview
 * re-attaches whenever it mounts, the stream changes, or it has been paused by the browser.
 */
function CameraPreview({ pipeline, guide, streaming, ready }) {
  const { t } = useI18n();
  const videoRef = useRef(null);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return undefined;
    const attach = () => {
      const stream = pipeline.getVideo()?.srcObject;
      if (!stream) return;
      if (el.srcObject !== stream) el.srcObject = stream;
      el.muted = true;
      el.playsInline = true;
      if (el.paused) el.play().catch(() => {});
    };
    attach();
    const id = setInterval(attach, 1000);
    return () => clearInterval(id);
  }, [pipeline, streaming]);

  const ringColor = guide.aligned ? '#22c55e' : '#e2e8f0';
  const tone = !ready ? 'slate' : guide.key === GUIDE.NO_FACE ? 'rose' : guide.aligned ? 'emerald' : 'amber';

  return (
    <div className="space-y-3">
      <div className="relative aspect-[4/3] w-full overflow-hidden rounded-2xl bg-slate-900 ring-1 ring-beige-200">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          role="img"
          aria-label={t('welcome.previewAria')}
          className="absolute inset-0 h-full w-full scale-x-[-1] object-cover"
        />
        {!streaming && (
          <div className="absolute inset-0 flex items-center justify-center p-4 text-center text-sm text-slate-300">
            {t('welcome.previewOff')}
          </div>
        )}
        {streaming && ready && (
          <svg viewBox="0 0 100 75" className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden="true">
            <ellipse
              cx="50" cy="37.5" rx="24" ry="31" fill="none" stroke={ringColor}
              strokeWidth={guide.aligned ? 1.8 : 0.9} strokeDasharray={guide.aligned ? undefined : '3 2'}
              className="transition-all duration-300"
            />
          </svg>
        )}
      </div>
      {ready && (
        <div role="status" aria-live="polite" className={`rounded-xl px-3 py-2 text-center text-sm font-semibold ring-1 ${TONES[tone]}`}>
          {t(`guide.${guide.key}`)}
        </div>
      )}
    </div>
  );
}

export default function Welcome({ pipeline, onBegin }) {
  const { t } = useI18n();
  const [consent, setConsent] = useState(false);
  const [guide, setGuide] = useState(() => computeGuidance(null));
  const [light, setLight] = useState({ s: 'unknown', mean: 0, eye: 0, dark: false });
  const [track, setTrack] = useState({ ready: false, conf: 0 });
  const { status, streaming, devices, selectedDeviceId } = pipeline;
  const ready = status.phase === 'ready';
  const busy = status.phase === 'requesting' || status.phase === 'loading';

  // Refreshes at ~7 Hz from the latest detection, lighting and tracking snapshots.
  useEffect(() => {
    const id = setInterval(() => {
      setGuide(computeGuidance(pipeline.latestRef.current));
      const L = pipeline.lightingRef.current;
      const Q = pipeline.qualityRef.current;
      setLight({ s: lightStatus(L, Q), mean: L.mean, eye: Math.round((Q.eyeScore ?? 0) * 100), dark: Q.reasons?.includes('darkButTracking') });
      const T = pipeline.trackRef.current;
      setTrack({ ready: T.ready, conf: T.conf });
    }, 150);
    return () => clearInterval(id);
  }, [pipeline]);

  const faceOk = ready && guide.key !== GUIDE.NO_FACE;
  const centeredOk = ready && guide.aligned;
  const stableState = !ready || !faceOk || !track.ready ? 'unknown' : track.conf >= 0.7 ? 'ok' : 'bad';
  const lightState = ready && faceOk ? light.s : 'unknown';
  const lightOk = lightState === 'ok';
  const allGood = faceOk && centeredOk && stableState === 'ok' && lightOk;
  const canBegin = ready && faceOk && centeredOk && consent;

  // The cat always says what the real state is. Unverifiable checks never read as "fine".
  let cat = { state: 'explaining', msg: t('cat.camStart') };
  if (status.phase === 'error') cat = { state: 'error', msg: t('cat.camError') };
  else if (busy) cat = { state: 'waiting', msg: t('cat.camWaiting') };
  else if (ready && !faceOk) cat = { state: 'waiting', msg: t('cat.noFace') };
  else if (ready && !centeredOk) cat = { state: 'explaining', msg: t(`guide.${guide.key}`) };
  else if (ready && stableState === 'bad') cat = { state: 'explaining', msg: t('cat.unstable') };
  else if (ready && ['dark', 'bright', 'backlit', 'weak'].includes(lightState)) cat = { state: 'error', msg: t('cat.lightBad') };
  else if (ready && (stableState === 'unknown' || lightState === 'unknown')) cat = { state: 'waiting', msg: t('cat.lightChecking') };
  else if (ready && allGood) cat = { state: 'encouraging', msg: consent ? t('cat.consent') : t('cat.allGood') };

  const lightLabel = {
    unknown: t('welcome.lightUnknown'),
    dark: t('welcome.lightDark'),
    bright: t('welcome.lightBright'),
    backlit: t('welcome.lightBacklit'),
    weak: t('welcome.lightWeak', { e: light.eye }),
    ok: t(light.dark ? 'welcome.lightOkDark' : 'welcome.lightOkDetail', { v: Math.round(light.mean), e: light.eye }),
  }[lightState];
  const stableLabel =
    stableState === 'ok' ? t('welcome.stableOk', { v: Math.round(track.conf * 100) })
      : stableState === 'bad' ? t('welcome.stableBad') : t('welcome.stableUnknown');

  let buttonLabel = t('welcome.enable');
  if (status.phase === 'requesting') buttonLabel = t('welcome.waitingPermission');
  if (status.phase === 'loading') buttonLabel = t('welcome.loadingModel');
  if (ready) buttonLabel = t('welcome.begin');

  const cameraDetail =
    status.phase === 'error' ? t(`error.${status.code}`)
      : busy ? t('welcome.cameraStarting')
        : ready ? t('welcome.cameraGranted') : t('welcome.cameraIdle');

  return (
    <div className="mx-auto grid max-w-6xl gap-6 px-4 py-8 lg:grid-cols-2">
      <div className="space-y-4">
        <div className="rounded-[2rem] bg-mint-100 p-6">
          <CatGuide state={cat.state} size={190} message={cat.msg} className="justify-center" />
        </div>
        <Card>
          <ul className="divide-y divide-beige-100" aria-live="polite">
            <CheckRow status={ready ? 'ok' : busy ? 'busy' : status.phase === 'error' ? 'bad' : 'idle'} label={t('welcome.checkCamera')} detail={cameraDetail} />
            <CheckRow status={!ready ? 'idle' : faceOk ? 'ok' : 'bad'} label={t('welcome.checkFace')} />
            <CheckRow status={!ready || !faceOk ? 'idle' : centeredOk ? 'ok' : 'bad'} label={t('welcome.checkCentered')} />
            <CheckRow status={!ready ? 'idle' : stableState} label={t('welcome.checkStable')} detail={ready ? stableLabel : undefined} />
            <CheckRow
              status={!ready ? 'idle' : lightState === 'unknown' ? 'unknown' : lightOk ? 'ok' : 'bad'}
              label={t('welcome.checkLight')}
              detail={ready ? lightLabel : undefined}
            />
          </ul>
          {ready && !lightOk && <p className="mt-2 text-xs text-slate-500">{t('welcome.lightWarn')}</p>}
        </Card>
      </div>

      <Card className="space-y-4 self-start">
        <div className="flex items-center gap-2">
          <Camera className="h-5 w-5 text-teal-700" aria-hidden="true" />
          <h2 className="text-lg font-semibold">{t('welcome.precheck')}</h2>
        </div>

        <CameraPreview pipeline={pipeline} guide={guide} streaming={streaming} ready={ready} />

        {devices.length > 1 && (
          <label className="block space-y-1">
            <span className="text-sm font-medium text-slate-700">{t('welcome.cameraSelect')}</span>
            <select
              value={selectedDeviceId}
              onChange={(e) => pipeline.selectDevice(e.target.value)}
              className="w-full rounded-xl border border-beige-300 bg-white px-3 py-2 text-sm text-slate-800 focus:outline-none focus-visible:ring-4 focus-visible:ring-teal-300"
            >
              {devices.map((d) => (
                <option key={d.id} value={d.id}>{d.label || t('welcome.cameraDefault', { n: d.index })}</option>
              ))}
            </select>
          </label>
        )}

        <label className="flex cursor-pointer items-start gap-3 rounded-2xl bg-beige-50 p-3 text-sm text-slate-700">
          <input type="checkbox" className="mt-1 h-4 w-4 accent-teal-700" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
          <span>{t('welcome.consent')}</span>
        </label>

        {!ready ? (
          <Button className="w-full" onClick={() => pipeline.start()} disabled={busy}>
            {busy && <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />}
            {buttonLabel}
          </Button>
        ) : (
          <Button className="w-full" onClick={onBegin} disabled={!canBegin}>{buttonLabel}</Button>
        )}
        {ready && !canBegin && <p className="text-center text-xs text-slate-500">{t('welcome.completeChecks')}</p>}
      </Card>
    </div>
  );
}

import { ArrowRight, ArrowLeft, Lock } from 'lucide-react';
import { Badge, Button, Card, PrivacyBadge } from './ui.jsx';
import CatGuide from './CatGuide.jsx';
import { useI18n } from '../i18n/I18nProvider.jsx';

export default function Intro({ onStart, onEngineering }) {
  const { t, isAr } = useI18n();
  const Arrow = isAr ? ArrowLeft : ArrowRight;
  return (
    <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-10 lg:grid-cols-2">
      <div className="rounded-[2rem] bg-mint-100 p-6">
        <CatGuide state="greeting" size={230} message={t('cat.welcome')} className="justify-center" />
      </div>

      <div className="space-y-5">
        <PrivacyBadge />
        <h1 className="text-5xl font-extrabold tracking-tight text-teal-800">{t('common.appTitle')}</h1>
        <p className="text-lg text-slate-700">{t('intro.desc')}</p>
        <div className="flex flex-wrap items-center gap-3">
          <Button onClick={onStart} className="px-8 py-4 text-lg">
            {t('intro.start')} <Arrow className="h-5 w-5" aria-hidden="true" />
          </Button>
          <button
            type="button"
            onClick={onEngineering}
            className="text-sm font-semibold text-teal-700 underline-offset-4 hover:underline"
          >
            {t('welcome.openEngineering')}
          </button>
        </div>
        <Card className="bg-beige-50">
          <div className="flex items-start gap-3">
            <Lock className="mt-0.5 h-5 w-5 shrink-0 text-teal-700" aria-hidden="true" />
            <div>
              <h2 className="font-semibold text-slate-900">{t('intro.privacyTitle')}</h2>
              <p className="mt-1 text-sm text-slate-600">{t('intro.privacyBody')}</p>
            </div>
          </div>
        </Card>
        <Badge tone="amber">{t('common.protoBadge')}</Badge>
        <p className="text-sm text-slate-500">{t('intro.noDx')}</p>
      </div>
    </div>
  );
}

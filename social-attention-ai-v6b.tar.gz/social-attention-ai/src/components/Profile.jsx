import { useState } from 'react';
import { Flower2, Heart, Leaf, Moon, Star, Sun, Trash2 } from 'lucide-react';
import { Button, Card } from './ui.jsx';
import CatGuide from './CatGuide.jsx';
import { useI18n } from '../i18n/I18nProvider.jsx';
import { AVATARS, clearProfile, saveProfile } from '../lib/profileStore.js';

const ICONS = { star: Star, heart: Heart, sun: Sun, moon: Moon, leaf: Leaf, flower: Flower2 };
const COLORS = {
  star: 'bg-amber-100 text-amber-600',
  heart: 'bg-rose-100 text-rose-500',
  sun: 'bg-orange-100 text-orange-500',
  moon: 'bg-indigo-100 text-indigo-500',
  leaf: 'bg-mint-200 text-teal-700',
  flower: 'bg-pink-100 text-pink-500',
};

export default function Profile({ initial, onContinue }) {
  const { t } = useI18n();
  const [nickname, setNickname] = useState(initial?.nickname ?? '');
  const [age, setAge] = useState(initial ? String(initial.age) : '');
  const [avatar, setAvatar] = useState(initial?.avatar ?? 'star');
  const [error, setError] = useState('');
  const [deleted, setDeleted] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    const n = nickname.trim();
    const a = Number(age);
    if (!n) return setError(t('prof.errNickname'));
    if (!Number.isInteger(a) || a < 1 || a > 18) return setError(t('prof.errAge'));
    const profile = { nickname: n.slice(0, 24), age: a, avatar };
    saveProfile(profile);
    onContinue(profile);
  };

  const remove = () => {
    clearProfile();
    setNickname('');
    setAge('');
    setAvatar('star');
    setDeleted(true);
    onContinue(null, { stay: true });
  };

  return (
    <div className="mx-auto grid max-w-5xl items-start gap-8 px-4 py-10 lg:grid-cols-2">
      <div className="rounded-[2rem] bg-mint-100 p-6">
        <CatGuide state="explaining" size={200} message={t('cat.profile')} className="justify-center" />
      </div>

      <Card className="space-y-5 p-6">
        <h1 className="text-2xl font-bold text-teal-800">{t('prof.title')}</h1>
        <form onSubmit={submit} className="space-y-5" noValidate>
          <label className="block space-y-1">
            <span className="text-sm font-semibold text-slate-700">{t('prof.nickname')}</span>
            <input
              value={nickname}
              maxLength={24}
              onChange={(e) => { setNickname(e.target.value); setError(''); setDeleted(false); }}
              className="w-full rounded-xl border border-beige-300 bg-cream px-4 py-3 text-lg focus:outline-none focus-visible:ring-4 focus-visible:ring-teal-300"
            />
            <span className="text-xs text-slate-500">{t('prof.nicknameHint')}</span>
          </label>

          <label className="block space-y-1">
            <span className="text-sm font-semibold text-slate-700">{t('prof.age')}</span>
            <input
              type="number"
              inputMode="numeric"
              min="1"
              max="18"
              value={age}
              onChange={(e) => { setAge(e.target.value); setError(''); setDeleted(false); }}
              className="w-32 rounded-xl border border-beige-300 bg-cream px-4 py-3 text-lg focus:outline-none focus-visible:ring-4 focus-visible:ring-teal-300"
            />
          </label>

          <fieldset>
            <legend className="mb-2 text-sm font-semibold text-slate-700">{t('prof.avatar')}</legend>
            <div className="flex flex-wrap gap-3" role="radiogroup">
              {AVATARS.map((id) => {
                const Icon = ICONS[id];
                const on = avatar === id;
                return (
                  <button
                    key={id}
                    type="button"
                    role="radio"
                    aria-checked={on}
                    aria-label={t(`avatar.${id}`)}
                    onClick={() => setAvatar(id)}
                    className={`flex h-14 w-14 items-center justify-center rounded-full transition focus:outline-none focus-visible:ring-4 focus-visible:ring-teal-300 active:scale-95 ${COLORS[id]} ${
                      on ? 'ring-4 ring-teal-500' : 'ring-1 ring-beige-300 hover:ring-2'
                    }`}
                  >
                    <Icon className="h-7 w-7" aria-hidden="true" />
                  </button>
                );
              })}
            </div>
          </fieldset>

          {error && <p role="alert" className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</p>}
          {deleted && <p role="status" className="rounded-lg bg-mint-100 px-3 py-2 text-sm text-teal-800">{t('prof.deleted')}</p>}

          <div className="flex flex-wrap items-center justify-between gap-3">
            <Button type="submit">{t('prof.continue')}</Button>
            <button
              type="button"
              onClick={remove}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-rose-700 underline-offset-4 hover:underline"
            >
              <Trash2 className="h-4 w-4" aria-hidden="true" /> {t('prof.delete')}
            </button>
          </div>
          <p className="text-xs text-slate-500">{t('prof.saveNote')}</p>
        </form>
      </Card>
    </div>
  );
}

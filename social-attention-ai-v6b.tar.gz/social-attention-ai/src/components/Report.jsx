import { AlertTriangle, ArrowLeft, Download, FlaskConical, Printer, RotateCcw } from 'lucide-react';
import { Badge, Button, Card, Metric, TONES } from './ui.jsx';
import CatGuide from './CatGuide.jsx';
import { FIXATION_CEILING_MS, SHIFT_IDEAL_PER_MIN, ZONE } from '../lib/constants.js';
import { assessQuality } from '../lib/metrics.js';
import { calibrationToCsv, downloadText, samplesToCsv } from '../lib/exportUtils.js';
import { useI18n } from '../i18n/I18nProvider.jsx';

const fmt = (n, d = 1) => (Number.isFinite(n) ? n.toFixed(d) : '—');

/** Semicircular gauge; pathLength=100 lets the dash offset map directly to the score. */
function Gauge({ score, label }) {
  const s = Math.max(0, Math.min(100, score));
  return (
    <svg viewBox="0 0 200 118" className="mx-auto w-full max-w-[16rem]" role="img" aria-label={label} dir="ltr">
      <path d="M 10 100 A 90 90 0 0 1 190 100" fill="none" stroke="#ecdcc0" strokeWidth="14" strokeLinecap="round" pathLength="100" />
      <path
        d="M 10 100 A 90 90 0 0 1 190 100" fill="none" stroke="#228c9b" strokeWidth="14" strokeLinecap="round"
        pathLength="100" strokeDasharray="100" strokeDashoffset={100 - s} className="transition-all duration-700"
      />
      <text x="100" y="92" textAnchor="middle" className="fill-slate-900" fontSize="30" fontWeight="700">{fmt(s, 0)}</text>
      <text x="100" y="112" textAnchor="middle" className="fill-slate-500" fontSize="10">/ 100</text>
    </svg>
  );
}

function Bar({ label, value, color }) {
  return (
    <div>
      <div className="mb-1 flex justify-between gap-3 text-sm">
        <span className="font-medium text-slate-700">{label}</span>
        <span className="tabular-nums text-slate-600">{fmt(value)}%</span>
      </div>
      <div dir="ltr" className="h-4 overflow-hidden rounded-full bg-beige-100">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${Math.min(100, value)}%` }} />
      </div>
    </div>
  );
}

const ZONE_COLOR = { [ZONE.SOCIAL]: 'bg-teal-500', [ZONE.NON_SOCIAL]: 'bg-coral-400', [ZONE.OFF]: 'bg-slate-300' };

/** Gaze over time: the session cut into 60 slices, each coloured by its most common zone. */
function Timeline({ samples, durationMs }) {
  const bins = 60;
  const tally = Array.from({ length: bins }, () => ({ [ZONE.SOCIAL]: 0, [ZONE.NON_SOCIAL]: 0, [ZONE.OFF]: 0 }));
  samples.forEach((s) => {
    const i = Math.min(bins - 1, Math.max(0, Math.floor((s.t / durationMs) * bins)));
    tally[i][s.zone] += 1;
  });
  return (
    <div dir="ltr" className="flex h-8 overflow-hidden rounded-lg" role="img" aria-hidden="true">
      {tally.map((b, i) => {
        const total = b[ZONE.SOCIAL] + b[ZONE.NON_SOCIAL] + b[ZONE.OFF];
        const zone = total === 0 ? ZONE.OFF : Object.keys(b).reduce((a, k) => (b[k] > b[a] ? k : a), ZONE.OFF);
        return <div key={i} className={`h-full flex-1 ${ZONE_COLOR[zone]}`} />;
      })}
    </div>
  );
}

const COMPONENT_KEYS = {
  socialFixation: 'report.compSocial',
  fixationDuration: 'report.compFix',
  shiftRate: 'report.compShift',
  onScreen: 'report.compOn',
};

export default function Report({ result, onRestart, onBack }) {
  const { t, lang } = useI18n();
  const { analysis: a, samples, networkExternal, calibrationErr, avgFps, startedAt, durationMs, synthetic } = result;
  const participant = result.participant ?? { nickname: '—', age: null };
  const sourceText = result.stimulusSource === 'local-file' ? t('stim.local') : result.stimulusSource === 'clip' ? t('stim.clip') : t('stim.generated');
  const dateText = new Date(startedAt).toLocaleString(lang === 'ar' ? 'ar' : 'en-GB');
  const Back = onBack ? (
    <Button variant="secondary" onClick={onBack}><ArrowLeft className="h-4 w-4" aria-hidden="true" /> {t('common.back')}</Button>
  ) : null;

  if (!a.valid) {
    return (
      <div className="mx-auto max-w-2xl space-y-4 px-4 py-10">
        <Card className="space-y-3">
          <CatGuide state="error" size={130} message={t('cat.doneBad')} />
          <div className="flex items-center gap-2 text-amber-700">
            <AlertTriangle className="h-6 w-6" aria-hidden="true" />
            <h1 className="text-xl font-bold">{t('report.insufficientTitle')}</h1>
          </div>
          <p className="text-slate-600">{t('report.insufficientBody', { s: fmt(a.validMs / 1000) })}</p>
          <div className="flex gap-2">
            <Button onClick={onRestart}><RotateCcw className="h-4 w-4" aria-hidden="true" /> {t('report.startNew')}</Button>
            {Back}
          </div>
        </Card>
      </div>
    );
  }

  const quality = assessQuality(a, calibrationErr);
  const privacyOk = networkExternal && networkExternal.length === 0;
  const prefix = synthetic ? 'SYNTHETIC-' : '';
  const exportCsv = () => downloadText(`${prefix}social-attention-samples-${Date.now()}.csv`, samplesToCsv(samples));
  const exportFeatures = () => downloadText(`calibration-features-${Date.now()}.csv`, calibrationToCsv(result.calibRaw, startedAt));
  const rows = [
    [t('report.projectLabel'), t('common.appTitle')],
    [t('report.participantLabel'), participant.nickname],
    ...(participant.age ? [[t('report.ageLabel'), participant.age]] : []),
    [t('report.dateLabel'), dateText],
    [t('report.durationLabel'), `${durationMs / 1000} s`],
  ];

  return (
    <div className="mx-auto max-w-5xl space-y-6 px-4 py-8 print:max-w-none print:px-0">
      {synthetic && (
        <div role="alert" className="flex items-center gap-2 rounded-2xl bg-coral-500 px-4 py-3 font-bold text-white">
          <FlaskConical className="h-5 w-5 shrink-0" aria-hidden="true" /> {t('synth.banner')}
        </div>
      )}

      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-teal-800">{t('report.title')}</h1>
          <dl className="mt-2 grid grid-cols-[auto_1fr] gap-x-4 gap-y-0.5 text-sm">
            {rows.map(([k, v]) => (
              <div key={k} className="contents">
                <dt className="text-slate-500">{k}</dt>
                <dd className="font-medium text-slate-800">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
        <div className="flex flex-wrap gap-2 print:hidden">
          {Back}
          <Button variant="secondary" onClick={exportCsv}><Download className="h-4 w-4" aria-hidden="true" /> {t('report.csv')}</Button>
          {!synthetic && result.calibRaw?.length > 0 && (
            <Button variant="secondary" onClick={exportFeatures}><Download className="h-4 w-4" aria-hidden="true" /> {t('report.exportFeatures')}</Button>
          )}
          <Button variant="secondary" onClick={() => window.print()}><Printer className="h-4 w-4" aria-hidden="true" /> {t('report.print')}</Button>
          {!synthetic && <Button onClick={onRestart}><RotateCcw className="h-4 w-4" aria-hidden="true" /> {t('report.newSession')}</Button>}
        </div>
      </header>

      {!synthetic && (
        <div className="print:hidden">
          <CatGuide state={quality.ok ? 'success' : 'error'} size={130} message={quality.ok ? t('cat.done') : t('cat.doneBad')} />
        </div>
      )}

      <div role="note" className="rounded-2xl bg-beige-100 p-4 text-sm font-medium text-slate-800">{t('report.disclaimer')}</div>

      <Card className={quality.ok ? 'bg-mint-50' : 'bg-rose-50'}>
        <p className={`font-semibold ${quality.ok ? 'text-teal-800' : 'text-rose-800'}`}>
          {quality.ok ? t('report.qualityOk') : t('report.qualityBad')}
        </p>
        {!quality.ok && (
          <ul className="mt-2 list-disc space-y-1 ps-5 text-sm text-rose-800">
            {quality.reasons.map((r) => <li key={r.key}>{t(`quality.${r.key}`, { v: r.v })}</li>)}
          </ul>
        )}
        <p className="mt-2 text-xs text-slate-500">{t('quality.note')}</p>
      </Card>

      <p className="text-sm text-slate-600">{t('report.sfrLine', { pct: fmt(a.socialFixationPct), non: fmt(a.nonSocialFixationPct) })}</p>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Metric kind="estimated" label={t('report.metricSfr')} value={fmt(a.socialFixationPct)} unit="%" hint={t('report.metricSfrHint')} />
        <Metric kind="estimated" label={t('report.metricNon')} value={fmt(a.nonSocialFixationPct)} unit="%" hint={t('report.metricNonHint')} />
        <Metric kind="estimated" label={t('report.metricShift')} value={fmt(a.shiftsPerMin)} unit={t('report.metricShiftUnit')} hint={t('report.metricShiftHint', { n: a.shiftCount })} />
        <Metric kind="estimated" label={t('report.metricFix')} value={fmt(a.avgFixationMs, 0)} unit="ms" hint={t('report.metricFixHint', { n: a.fixationCount })} />
        <Metric kind="estimated" label={t('report.metricOff')} value={fmt(a.offMs / 1000)} unit="s" hint={t('report.metricOffHint', { p: fmt(a.offScreenPct) })} />
        <Metric kind="estimated" label={t('report.metricTrack')} value={fmt(a.trackingConfidence * 100, 0)} unit="%" hint={t('report.metricTrackHint')} />
        <Metric kind="measured" label={t('report.metricValid')} value={fmt(a.validDataPct)} unit="%" hint={t('report.metricValidHint')} />
        <Metric
          kind={calibrationErr == null ? 'missing' : 'estimated'}
          label={t('report.metricCalib')}
          value={calibrationErr == null ? '—' : fmt(calibrationErr * 100)}
          unit={calibrationErr == null ? '' : '%'}
          hint={t('report.metricCalibHint')}
        />
      </section>
      <p className="text-xs text-slate-500">{t('report.legend')}</p>

      <Card className="space-y-4">
        <h2 className="text-lg font-semibold">{t('report.timeTitle')}</h2>
        <Bar label={t('report.barSocial')} value={(a.socialMs / a.totalMs) * 100} color="bg-teal-500" />
        <Bar label={t('report.barNonSocial')} value={(a.nonMs / a.totalMs) * 100} color="bg-coral-400" />
        <Bar label={t('report.barOff')} value={a.offScreenPct} color="bg-slate-400" />
        <p className="text-xs text-slate-500">{t('report.barsNote')}</p>
        <div>
          <h3 className="mb-2 text-sm font-semibold text-slate-700">{t('report.timeline')}</h3>
          <Timeline samples={samples} durationMs={durationMs} />
          <div className="mt-2 flex flex-wrap gap-3 text-xs text-slate-600">
            <span className="flex items-center gap-1"><i className="h-3 w-3 rounded bg-teal-500" /> {t('report.barSocial')}</span>
            <span className="flex items-center gap-1"><i className="h-3 w-3 rounded bg-coral-400" /> {t('report.barNonSocial')}</span>
            <span className="flex items-center gap-1"><i className="h-3 w-3 rounded bg-slate-300" /> {t('report.barOff')}</span>
          </div>
          <p className="mt-1 text-xs text-slate-500">{t('report.timelineNote')}</p>
        </div>
      </Card>

      <Card className="grid items-start gap-6 md:grid-cols-2">
        <div>
          <p className="mb-1 text-sm font-semibold text-slate-600">{t('report.sai')}</p>
          <Gauge score={a.sai.score} label={`${t('report.sai')}: ${fmt(a.sai.score, 0)} / 100`} />
        </div>
        <div className="space-y-3 text-sm">
          <h2 className="text-lg font-semibold">{t('report.scoreTitle')}</h2>
          <p className="rounded-lg bg-beige-50 p-2 font-mono text-xs text-slate-700" dir="ltr">{t('report.formula')}</p>
          <p className="text-xs text-slate-600">{t('report.formulaDetail')}</p>
          <p className="text-xs font-medium text-slate-700">{t('report.scoreNote')}</p>
        </div>
        <table className="w-full text-sm md:col-span-2">
          <thead>
            <tr className="border-b text-slate-500">
              <th className="py-2 text-start font-medium">{t('report.colComponent')}</th>
              <th className="py-2 text-end font-medium">{t('report.colValue')}</th>
              <th className="py-2 text-end font-medium">{t('report.colWeight')}</th>
              <th className="py-2 text-end font-medium">{t('report.colContribution')}</th>
            </tr>
          </thead>
          <tbody>
            {a.sai.components.map((c) => (
              <tr key={c.key} className="border-b border-beige-100">
                <td className="py-2 text-start">{t(COMPONENT_KEYS[c.key], { ceiling: FIXATION_CEILING_MS, ideal: SHIFT_IDEAL_PER_MIN })}</td>
                <td className="py-2 text-end tabular-nums">{fmt(c.value)}</td>
                <td className="py-2 text-end tabular-nums">{c.weight.toFixed(2)}</td>
                <td className="py-2 text-end tabular-nums">{fmt(c.contribution)}</td>
              </tr>
            ))}
            <tr className="font-semibold">
              <td className="py-2 text-start">{t('report.total')}</td>
              <td /><td />
              <td className="py-2 text-end tabular-nums">{fmt(a.sai.score)}</td>
            </tr>
          </tbody>
        </table>
      </Card>

      <Card className="space-y-2 text-sm text-slate-700">
        <h2 className="text-lg font-semibold">{t('report.methodTitle')}</h2>
        <ul className="list-disc space-y-1 ps-5">
          <li>{t('report.method1')}</li>
          <li>{t('report.method2')}</li>
          <li>{t('report.method3', { s: sourceText })}</li>
          <li>{t('report.method4')}</li>
        </ul>
      </Card>

      <Card className="space-y-2 text-sm text-slate-700">
        <h2 className="text-lg font-semibold">{t('report.limTitle')}</h2>
        <ul className="list-disc space-y-1 ps-5">
          <li>{t('report.lim1')}</li>
          <li>{t('report.lim2')}</li>
          <li>{t('report.lim3')}</li>
          <li>{t('report.lim4')}</li>
        </ul>
      </Card>

      <Card className="grid gap-4 text-sm md:grid-cols-2">
        <div>
          <h2 className="mb-2 text-lg font-semibold">{t('report.techTitle')}</h2>
          <ul className="space-y-1 text-slate-600">
            <li>{t('report.validTime', { v: fmt(a.validMs / 1000), o: fmt(a.offMs / 1000) })}</li>
            <li>{t('report.samples', { n: samples.length })}</li>
            {avgFps != null && <li>{fmt(avgFps, 0)} FPS</li>}
          </ul>
        </div>
        <div className="space-y-2">
          <h2 className="text-lg font-semibold">{t('report.privTitle')}</h2>
          <p className="text-slate-600">{t('report.privBody')}</p>
          {!synthetic && networkExternal && (
            <div className={`rounded-xl p-3 ring-1 ${privacyOk ? TONES.emerald : TONES.amber}`}>
              <p className="font-semibold">{privacyOk ? t('report.privacyOk') : t('report.privacyFail')}</p>
              <p className="text-xs">{privacyOk ? t('report.privacyOkBody') : t('report.privacyFailBody', { list: networkExternal.join(', ') })}</p>
            </div>
          )}
        </div>
      </Card>

      <p className="text-center text-xs text-slate-400 print:text-black">{t('report.footer')}</p>
    </div>
  );
}

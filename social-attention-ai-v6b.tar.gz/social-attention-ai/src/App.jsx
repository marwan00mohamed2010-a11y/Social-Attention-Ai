import { useCallback, useEffect, useState } from 'react';
import { Cpu, ScanFace } from 'lucide-react';
import { useVisionPipeline } from './hooks/useVisionPipeline.js';
import { analyzeSession } from './lib/metrics.js';
import { externalRequestsSince } from './lib/perfMonitor.js';
import { loadProfile } from './lib/profileStore.js';
import { buildSyntheticResult } from './lib/synthetic.js';
import { PrivacyBadge } from './components/ui.jsx';
import LanguageToggle from './components/LanguageToggle.jsx';
import Intro from './components/Intro.jsx';
import Profile from './components/Profile.jsx';
import Welcome from './components/Welcome.jsx';
import Calibration from './components/Calibration.jsx';
import Assessment from './components/Assessment.jsx';
import Report from './components/Report.jsx';
import EngineeringPanel from './components/EngineeringPanel.jsx';
import VisionLab from './components/VisionLab.jsx';
import { useI18n } from './i18n/I18nProvider.jsx';

export default function App() {
  const { t } = useI18n();
  const pipeline = useVisionPipeline();
  const [view, setView] = useState('app');        // app | engineering | lab | synthReport
  const [stage, setStage] = useState('intro');    // intro | profile | precheck | calibrate | assess | report
  const [profile, setProfile] = useState(() => loadProfile());
  const [calibration, setCalibration] = useState(null);
  const [calibRaw, setCalibRaw] = useState([]);
  const [result, setResult] = useState(null);     // REAL session only
  const [synthResult, setSynthResult] = useState(null); // SYNTHETIC only, never shown as a real result

  const restart = useCallback(() => {
    setResult(null);
    setCalibration(null);
    setStage('precheck');
    pipeline.start(); // reopen the camera for the new session (this click is the user gesture)
  }, [pipeline]);

  const handleSessionDone = useCallback(
    ({ samples, durationMs, sessionStartedAt, stimulusSource }) => {
      setResult({
        analysis: analyzeSession(samples, durationMs),
        samples,
        durationMs,
        startedAt: new Date().toISOString(),
        networkExternal: externalRequestsSince(sessionStartedAt),
        calibrationErr: calibration?.gateError ?? calibration?.looError ?? null,
        avgFps: pipeline.telemetry.fps,
        participant: profile ?? { nickname: '—', age: null },
        stimulusSource,
        calibRaw,
      });
      setStage('report');
    },
    [calibration, calibRaw, profile, pipeline.telemetry.fps],
  );

  // Session finished -> turn the camera off. A new session reopens it (see restart / the pre-check button).
  useEffect(() => {
    if (view === 'app' && stage === 'report') pipeline.release();
  }, [view, stage, pipeline.release]);

  // Keep the source stream playing through every stage change (App stays mounted for the whole session).
  useEffect(() => {
    const resume = () => {
      const v = pipeline.getVideo();
      if (v?.srcObject && v.paused) v.play().catch(() => {});
    };
    resume();
    const id = setInterval(resume, 1000);
    return () => clearInterval(id);
  }, [pipeline, stage, view]);

  const immersive = view === 'app' && stage === 'assess';

  let body;
  if (view === 'lab') {
    body = <VisionLab pipeline={pipeline} calibration={calibration} onBack={() => setView('engineering')} />;
  } else if (view === 'engineering') {
    body = (
      <EngineeringPanel
        pipeline={pipeline}
        onOpenLab={() => setView('lab')}
        onBack={() => setView('app')}
        onSyntheticReport={(id) => {
          setSynthResult(buildSyntheticResult(id, analyzeSession));
          setView('synthReport');
        }}
      />
    );
  } else if (view === 'synthReport' && synthResult) {
    body = <Report result={synthResult} onBack={() => setView('engineering')} onRestart={() => setView('engineering')} />;
  } else if (stage === 'intro') {
    body = <Intro onStart={() => setStage('profile')} onEngineering={() => setView('engineering')} />;
  } else if (stage === 'profile') {
    body = (
      <Profile
        initial={profile}
        onContinue={(p, opts) => {
          setProfile(p);
          if (!opts?.stay) setStage('precheck');
        }}
      />
    );
  } else if (stage === 'precheck') {
    body = <Welcome pipeline={pipeline} onBegin={() => setStage('calibrate')} />;
  } else if (stage === 'calibrate') {
    body = (
      <Calibration
        pipeline={pipeline}
        onBack={() => setStage('precheck')}
        onComplete={(model, raw) => {
          setCalibration(model);
          setCalibRaw(raw);
          setStage('assess');
        }}
      />
    );
  } else if (stage === 'assess') {
    body = <Assessment pipeline={pipeline} calibration={calibration} onAbort={() => setStage('precheck')} onComplete={handleSessionDone} />;
  } else {
    body = result && <Report result={result} onRestart={restart} />;
  }

  return (
    <div className="min-h-screen bg-cream font-sans text-slate-900 antialiased">
      {/*
        Source video. It stays mounted for the whole session so the stream is never detached. It is fixed to
        the viewport because browsers pause muted video that has scrolled out of view.
      */}
      <video
        ref={pipeline.bindVideo}
        autoPlay
        playsInline
        muted
        aria-hidden="true"
        tabIndex={-1}
        className="pointer-events-none fixed left-0 top-0 z-0 h-px w-px opacity-[0.01]"
      />

      {!immersive && (
        <header className="sticky top-0 z-20 border-b border-beige-200 bg-cream/95 print:hidden">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
            <button
              type="button"
              onClick={() => { setView('app'); setStage('intro'); }}
              className="flex items-center gap-2 rounded-lg focus:outline-none focus-visible:ring-4 focus-visible:ring-teal-300"
            >
              <ScanFace className="h-6 w-6 text-teal-700" aria-hidden="true" />
              <span className="font-bold tracking-tight text-teal-800">{t('common.appTitle')}</span>
            </button>
            <div className="flex items-center gap-3">
              <PrivacyBadge className="hidden xl:inline-flex" />
              <button
                type="button"
                onClick={() => setView(view === 'engineering' ? 'app' : 'engineering')}
                className="inline-flex items-center gap-1.5 rounded-full bg-white px-3.5 py-1.5 text-sm font-semibold text-teal-800 ring-1 ring-beige-300 transition hover:bg-beige-50 active:bg-beige-100 focus:outline-none focus-visible:ring-4 focus-visible:ring-teal-300"
              >
                <Cpu className="h-4 w-4" aria-hidden="true" /> {t('nav.engineering')}
              </button>
              <LanguageToggle />
            </div>
          </div>
        </header>
      )}

      <main>{body}</main>

      {!immersive && (
        <footer className="mx-auto max-w-6xl px-4 pb-8 pt-4 text-center text-xs text-slate-500 print:hidden">
          {t('common.footer')}
        </footer>
      )}
    </div>
  );
}

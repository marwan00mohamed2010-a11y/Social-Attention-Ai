import { useCallback, useEffect, useRef, useState } from 'react';
import { checkModelAvailable, createFaceLandmarker } from '../lib/visionEngine.js';
import { extractIrisFeatures, headPoseFromLandmarks, headPoseFromMatrix } from '../lib/gazeMath.js';
import { FrameMeter } from '../lib/perfMonitor.js';
import { AutoEnhanceGate, enhanceRGBA, lumaStats } from '../lib/enhance.js';
import { QualityWindow, assessTracking, imageScore } from '../lib/quality.js';
import { applyControls, loadPrefs, readCapabilities, savePrefs } from '../lib/cameraCaps.js';

const LIGHT_W = 32;
const LIGHT_H = 24;

function meanLuma(ctx) {
  const d = ctx.getImageData(0, 0, LIGHT_W, LIGHT_H).data;
  let sum = 0;
  for (let i = 0; i < d.length; i += 4) sum += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
  return sum / (d.length / 4);
}

/** Maps an error to a translation code (text lives in i18n/strings.js). */
function errorCode(err) {
  if (err?.appCode) return err.appCode;
  if (err?.name === 'NotAllowedError') return 'denied';
  if (err?.name === 'NotFoundError') return 'notFound';
  if (err?.name === 'NotReadableError') return 'inUse';
  return 'unknown';
}

function cameraConstraints(deviceId, cfg) {
  const size = {
    width: { ideal: cfg?.width ?? 640 },
    height: { ideal: cfg?.height ?? 480 },
    ...(cfg?.frameRate ? { frameRate: { ideal: cfg.frameRate } } : {}),
  };
  return {
    audio: false,
    video: deviceId ? { ...size, deviceId: { exact: deviceId } } : { ...size, facingMode: 'user' },
  };
}

/**
 * Owns the camera stream, the <video> element binding, the FaceLandmarker and the detection loop.
 * The stream is opened once and kept alive across Pre-check, Calibration and Assessment.
 * It is only released when the app unmounts.
 */
export function useVisionPipeline() {
  const videoElRef = useRef(null);
  const streamRef = useRef(null);
  const latestRef = useRef(null);
  const lightingRef = useRef({ mean: 0, stability: 0, ready: false });
  const listenersRef = useRef(new Set());
  const landmarkerRef = useRef(null);
  const rafRef = useRef(0);
  const loopRunningRef = useRef(false);
  const keepAliveRef = useRef(0);
  const telemetryTimerRef = useRef(0);
  const latencyRef = useRef(0);
  const meterRef = useRef(new FrameMeter());
  const startingRef = useRef(false);
  const selectedRef = useRef('');
  const trackWinRef = useRef({ found: [], jit: [], last: null });
  const trackRef = useRef({ continuity: 0, jitter: 0, conf: 0, ready: false });
  // Enhancement is OFF by default: it is only worth using if Vision Lab measurements show it helps on this camera.
  const enhanceModeRef = useRef(loadPrefs().enhanceMode ?? 'off'); // off | auto | on
  const cameraCfgRef = useRef(loadPrefs().cameraCfg ?? null);
  const enhanceInfoRef = useRef({ active: false, gamma: 1, ms: 0 });
  const qualityRef = useRef({ level: 'measuring', reasons: [] });
  const qWinRef = useRef(new QualityWindow(45));
  const pausedRef = useRef(false); // Vision Lab pauses the live loop while it measures, so timings are not shared

  const [status, setStatus] = useState({ phase: 'idle', code: '' });
  const [streaming, setStreaming] = useState(false);
  const [telemetry, setTelemetry] = useState({ fps: 0, latencyMs: 0 });
  const [devices, setDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [engine, setEngine] = useState({ delegate: '' });
  const [cameraInfo, setCameraInfo] = useState({ label: '', width: 0, height: 0 });
  const [enhanceMode, setEnhanceModeState] = useState(enhanceModeRef.current);
  const [camCaps, setCamCaps] = useState(null);

  const subscribe = useCallback((fn) => {
    listenersRef.current.add(fn);
    return () => listenersRef.current.delete(fn);
  }, []);

  /** Attaches the live stream to the <video> element and starts playback. Safe to call repeatedly. */
  const playVideo = useCallback(async () => {
    const el = videoElRef.current;
    const stream = streamRef.current;
    if (!el || !stream) return;
    if (el.srcObject !== stream) el.srcObject = stream;
    el.muted = true;
    el.playsInline = true;
    if (el.paused) {
      try {
        await el.play();
      } catch (err) {
        console.warn('video.play() was blocked; it will be retried.', err);
      }
    }
  }, []);

  /**
   * Callback ref: runs every time the <video> mounts or re-mounts, so the stream is always attached.
   */
  const bindVideo = useCallback(
    (el) => {
      videoElRef.current = el;
      if (el) playVideo();
    },
    [playVideo],
  );

  const getVideo = useCallback(() => videoElRef.current, []);

  const refreshDevices = useCallback(async () => {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    const all = await navigator.mediaDevices.enumerateDevices();
    const cams = all
      .filter((d) => d.kind === 'videoinput')
      .map((d, i) => ({ id: d.deviceId, label: d.label, index: i + 1 }));
    setDevices(cams);
    const active = streamRef.current?.getVideoTracks()[0]?.getSettings().deviceId;
    if (active) {
      selectedRef.current = active;
      setSelectedDeviceId(active);
    }
  }, []);

  const stopTracks = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setStreaming(false);
  }, []);

  /** Fully releases the camera (light turns off). The face model stays loaded, so reopening is fast. */
  const release = useCallback(() => {
    stopTracks();
    const el = videoElRef.current;
    if (el) el.srcObject = null;
    latestRef.current = null;
    qWinRef.current.reset();
    trackWinRef.current = { found: [], jit: [], last: null };
    trackRef.current = { continuity: 0, jitter: 0, conf: 0, ready: false };
    lightingRef.current = { mean: 0, stability: 0, ready: false };
    setCameraInfo({ label: '', width: 0, height: 0 });
    setStatus({ phase: 'idle', code: '' });
  }, [stopTracks]);

  /** Opens a camera (optionally a specific device) and attaches it. Falls back to the default camera. */
  const openCamera = useCallback(
    async (deviceId) => {
      stopTracks();
      let stream;
      try {
        stream = await navigator.mediaDevices.getUserMedia(cameraConstraints(deviceId, cameraCfgRef.current));
      } catch (err) {
        if (!deviceId || err?.name !== 'OverconstrainedError') throw err;
        stream = await navigator.mediaDevices.getUserMedia(cameraConstraints(undefined, cameraCfgRef.current));
      }
      streamRef.current = stream;
      const track = stream.getVideoTracks()[0];
      const st = track?.getSettings?.() ?? {};
      setCameraInfo({ label: track?.label ?? '', width: st.width ?? 0, height: st.height ?? 0, frameRate: st.frameRate ?? 0 });
      setCamCaps(readCapabilities(track));
      setStreaming(true);
      await playVideo();
      await refreshDevices();
    },
    [stopTracks, playVideo, refreshDevices],
  );

  /** Switches camera without reloading the face model. */
  const selectDevice = useCallback(
    async (deviceId) => {
      selectedRef.current = deviceId;
      setSelectedDeviceId(deviceId);
      if (!streamRef.current) return;
      try {
        await openCamera(deviceId);
      } catch (err) {
        setStatus({ phase: 'error', code: errorCode(err) });
      }
    },
    [openCamera],
  );

  const startKeepAlive = useCallback(() => {
    if (keepAliveRef.current) return;
    // Browsers may pause a muted video, so resume it every second while the stream is open.
    keepAliveRef.current = setInterval(() => {
      if (streamRef.current) playVideo();
    }, 1000);
  }, [playVideo]);

  const startLoop = useCallback(() => {
    if (loopRunningRef.current) return;
    loopRunningRef.current = true;

    const lightCanvas = document.createElement('canvas');
    lightCanvas.width = LIGHT_W;
    lightCanvas.height = LIGHT_H;
    const lctx = lightCanvas.getContext('2d', { willReadFrequently: true });
    const lumHistory = [];
    let lastLightAt = -Infinity;
    let lastVideoTime = -1;
    // Work canvas for enhancement. Same size as the video, so landmarks need NO coordinate transform.
    const work = document.createElement('canvas');
    const wctx = work.getContext('2d', { willReadFrequently: true });
    const gate = new AutoEnhanceGate();
    let lastFaceBox = null;
    let lastMedian = 128;

    const loop = (now) => {
      rafRef.current = requestAnimationFrame(loop);
      const v = videoElRef.current;
      const lm = landmarkerRef.current;
      if (pausedRef.current) return;
      if (!v || !lm || !streamRef.current || v.readyState < 2 || v.currentTime === lastVideoTime) return;
      lastVideoTime = v.currentTime;

      const t0 = performance.now();
      let res;
      try {
        const mode = enhanceModeRef.current;
        const useEnh = mode === 'on' || (mode === 'auto' && gate.update(lastMedian));
        let input = v;
        if (useEnh && v.videoWidth) {
          if (work.width !== v.videoWidth || work.height !== v.videoHeight) { work.width = v.videoWidth; work.height = v.videoHeight; }
          wctx.drawImage(v, 0, 0);
          const img = wctx.getImageData(0, 0, work.width, work.height);
          const roi = lastFaceBox
            ? { x: lastFaceBox.x0 * work.width, y: lastFaceBox.y0 * work.height, w: (lastFaceBox.x1 - lastFaceBox.x0) * work.width, h: (lastFaceBox.y1 - lastFaceBox.y0) * work.height }
            : null;
          const info = enhanceRGBA(img.data, work.width, work.height, {}, roi);
          wctx.putImageData(img, 0, 0);
          input = work;
          enhanceInfoRef.current = { active: true, gamma: info.gamma, ms: performance.now() - t0 };
        } else {
          enhanceInfoRef.current = { active: false, gamma: 1, ms: 0 };
        }
        res = lm.detectForVideo(input, t0);
      } catch (err) {
        console.warn('Detection frame skipped:', err);
        return;
      }
      latencyRef.current = performance.now() - t0;

      const face = res.faceLandmarks?.[0];
      let frame;
      if (face && face.length >= 478) {
        const iris = extractIrisFeatures(face, (v.videoWidth || 4) / (v.videoHeight || 3));
        const matrix = res.facialTransformationMatrixes?.[0]?.data;
        const pose = matrix ? headPoseFromMatrix(matrix) : headPoseFromLandmarks(face);
        frame = {
          t: now,
          faceFound: true,
          landmarks: face,
          irisX: iris.irisX,
          irisY: iris.irisY,
          openness: iris.openness,
          eyeValid: iris.eyeValid,
          yawDeg: pose.yawDeg,
          pitchDeg: pose.pitchDeg,
          nose: { x: face[1].x, y: face[1].y },
        };
      } else {
        frame = { t: now, faceFound: false, landmarks: null, nose: null, eyeValid: false };
      }
      qWinRef.current.push(frame);
      // Tracking confidence is a HEURISTIC (not a model probability): face continuity over the last
      // 30 frames multiplied by how steady the nose position is. Zero when the face is lost.
      const win = trackWinRef.current;
      win.found.push(frame.faceFound ? 1 : 0);
      if (win.found.length > 30) win.found.shift();
      if (frame.faceFound) {
        if (win.last) {
          win.jit.push(Math.hypot(frame.nose.x - win.last.x, frame.nose.y - win.last.y));
          if (win.jit.length > 30) win.jit.shift();
        }
        win.last = frame.nose;
      } else {
        win.last = null;
      }
      const continuity = win.found.reduce((a, b) => a + b, 0) / win.found.length;
      const jitter = win.jit.length ? win.jit.reduce((a, b) => a + b, 0) / win.jit.length : 0;
      const conf = frame.faceFound ? continuity * Math.max(0, 1 - jitter / 0.015) : 0;
      frame.conf = conf;
      trackRef.current = { continuity, jitter, conf, ready: win.found.length >= 30 };
      latestRef.current = frame;
      meterRef.current.tick(performance.now());

      // Lighting: brightness of the FACE region (falls back to the whole frame) and its stability over
      // ~3 s. "backlit" = the face is much darker than the frame. All values are estimates from pixels.
      if (now - lastLightAt > 250) {
        lastLightAt = now;
        const vw = v.videoWidth;
        const vh = v.videoHeight;
        lctx.drawImage(v, 0, 0, LIGHT_W, LIGHT_H);
        const frameMean = meanLuma(lctx);
        let mean = frameMean;
        let faceMeasured = false;
        let faceStats = null;
        if (frame.faceFound && vw && vh) {
          let x0 = 1; let x1 = 0; let y0 = 1; let y1 = 0;
          for (const p of frame.landmarks) {
            if (p.x < x0) x0 = p.x;
            if (p.x > x1) x1 = p.x;
            if (p.y < y0) y0 = p.y;
            if (p.y > y1) y1 = p.y;
          }
          if (x1 - x0 > 0.05 && y1 - y0 > 0.05) {
            lastFaceBox = { x0, x1, y0, y1 };
            lctx.drawImage(v, x0 * vw, y0 * vh, (x1 - x0) * vw, (y1 - y0) * vh, 0, 0, LIGHT_W, LIGHT_H);
            mean = meanLuma(lctx);
            faceStats = lumaStats(lctx.getImageData(0, 0, LIGHT_W, LIGHT_H).data, 1);
            faceMeasured = true;
          }
        }
        lumHistory.push(mean);
        if (lumHistory.length > 12) lumHistory.shift();
        const m = lumHistory.reduce((a, b) => a + b, 0) / lumHistory.length;
        const sd = Math.sqrt(lumHistory.reduce((a, b) => a + (b - m) ** 2, 0) / lumHistory.length);
        lightingRef.current = {
          mean, frameMean, faceMeasured,
          stability: Math.max(0, 1 - sd / 25),
          backlit: faceMeasured && frameMean - mean > 50,
          ready: lumHistory.length >= 6 && faceMeasured,
          stats: faceStats,
        };
        if (faceStats) lastMedian = faceStats.p50;
        // Verdict from tracking evidence (eye validity, iris steadiness) + image statistics as the explanation.
        qualityRef.current = assessTracking(faceStats ? imageScore(faceStats) : null, qWinRef.current);
      }

      listenersRef.current.forEach((fn) => {
        try {
          fn(frame);
        } catch (err) {
          console.error('Frame listener error:', err);
        }
      });
    };

    rafRef.current = requestAnimationFrame(loop);
    telemetryTimerRef.current = setInterval(() => {
      setTelemetry({ fps: meterRef.current.fps, latencyMs: Math.round(latencyRef.current * 10) / 10 });
    }, 500);
  }, []);

  const setEnhanceMode = useCallback((m) => {
    enhanceModeRef.current = m;
    setEnhanceModeState(m);
    savePrefs({ ...loadPrefs(), enhanceMode: m });
  }, []);

  const getTrack = useCallback(() => streamRef.current?.getVideoTracks()[0] ?? null, []);

  /** Reopen the camera with a resolution/fps config (null = default 640x480). */
  const applyCameraConfig = useCallback(
    async (cfg) => {
      cameraCfgRef.current = cfg;
      savePrefs({ ...loadPrefs(), cameraCfg: cfg });
      await openCamera(selectedRef.current || undefined);
    },
    [openCamera],
  );

  /** Apply only camera controls this device reports as supported. */
  const applyCameraControls = useCallback(async (wanted) => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return { applied: [], skipped: Object.keys(wanted), error: 'no track' };
    const caps = readCapabilities(track);
    const r = await applyControls(track, wanted, caps);
    setCamCaps(readCapabilities(track));
    return r;
  }, []);

  const start = useCallback(async () => {
    if (startingRef.current) return;
    startingRef.current = true;
    try {
      if (!streamRef.current) {
        setStatus({ phase: 'requesting', code: '' });
        if (!navigator.mediaDevices?.getUserMedia) {
          throw Object.assign(new Error('unsupported'), { appCode: 'unsupported' });
        }
        await openCamera(selectedRef.current || undefined);
      }
      await playVideo();

      if (!landmarkerRef.current) {
        setStatus({ phase: 'loading', code: '' });
        await checkModelAvailable();
        landmarkerRef.current = await createFaceLandmarker();
        setEngine({ delegate: landmarkerRef.current.__delegate || '' });
      }

      setStatus({ phase: 'ready', code: '' });
      startLoop();
      startKeepAlive();
    } catch (err) {
      // The camera stays open if only the model failed, so a retry does not re-prompt for permission.
      setStatus({ phase: 'error', code: errorCode(err) });
    } finally {
      startingRef.current = false;
    }
  }, [openCamera, playVideo, startLoop, startKeepAlive]);

  // Resume playback when the tab becomes visible again, and track device hot-plug.
  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible') playVideo();
    };
    document.addEventListener('visibilitychange', onVisible);
    const md = navigator.mediaDevices;
    md?.addEventListener?.('devicechange', refreshDevices);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      md?.removeEventListener?.('devicechange', refreshDevices);
    };
  }, [playVideo, refreshDevices]);

  // Release everything only when the app itself unmounts.
  useEffect(() => {
    return () => {
      cancelAnimationFrame(rafRef.current);
      clearInterval(telemetryTimerRef.current);
      clearInterval(keepAliveRef.current);
      keepAliveRef.current = 0;
      loopRunningRef.current = false;
      stopTracks();
      landmarkerRef.current?.close();
      landmarkerRef.current = null;
    };
  }, [stopTracks]);

  return {
    bindVideo,
    getVideo,
    latestRef,
    lightingRef,
    trackRef,
    engine,
    cameraInfo,
    status,
    streaming,
    telemetry,
    devices,
    selectedDeviceId,
    selectDevice,
    enhanceMode,
    setEnhanceMode,
    pausedRef,
    enhanceInfoRef,
    qualityRef,
    camCaps,
    getTrack,
    applyCameraConfig,
    applyCameraControls,
    start,
    release,
    subscribe,
  };
}

// Copies the MediaPipe Wasm runtime into /public and downloads the face model once.
// Both are then served from this origin, so the app never calls a CDN at runtime.
// Run "npm run fetch-model" to retry the model step on its own. Failures are non-fatal here.
import { cp, mkdir, stat, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const modelOnly = process.argv.includes('--model-only');
const MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task';
const modelPath = path.join(root, 'public', 'models', 'face_landmarker.task');

async function copyWasm() {
  const src = path.join(root, 'node_modules', '@mediapipe', 'tasks-vision', 'wasm');
  const dest = path.join(root, 'public', 'mediapipe', 'wasm');
  if (!existsSync(src)) {
    console.warn('[setup] @mediapipe/tasks-vision/wasm not found. Run npm install first.');
    return;
  }
  await mkdir(dest, { recursive: true });
  await cp(src, dest, { recursive: true });
  console.log('[setup] MediaPipe Wasm copied to public/mediapipe/wasm');
}

async function fetchModel() {
  if (existsSync(modelPath) && (await stat(modelPath)).size > 100_000) {
    console.log('[setup] Face model already present.');
    return;
  }
  await mkdir(path.dirname(modelPath), { recursive: true });
  try {
    const res = await fetch(MODEL_URL);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    await writeFile(modelPath, Buffer.from(await res.arrayBuffer()));
    console.log('[setup] Face model saved to public/models/face_landmarker.task');
  } catch (err) {
    console.warn(`[setup] Could not download the face model (${err.message}).`);
    console.warn(`[setup] Download it manually from ${MODEL_URL} and save it as public/models/face_landmarker.task`);
  }
}

if (!modelOnly) await copyWasm();
await fetchModel();

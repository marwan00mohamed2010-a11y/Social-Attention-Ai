# Research stimulus clips (optional)

The app currently uses **generated canvas animations** (a drawn avatar and rotating geometry). These are NOT
recorded videos and are not validated research stimuli.

To use real, properly licensed clips, place them here:

- `public/stimuli/social.mp4`     shown on the LEFT half
- `public/stimuli/nonsocial.mp4`  shown on the RIGHT half

Each side falls back to the generated animation on its own if its file is missing. The report records which
source was used. Keep luminance, motion and duration comparable between the two clips, and confirm the licence
and any consent requirements before use. Do not commit clips you are not allowed to redistribute.
